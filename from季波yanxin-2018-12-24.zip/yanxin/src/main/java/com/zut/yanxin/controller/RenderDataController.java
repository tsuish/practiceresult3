package com.zut.yanxin.controller;

import com.jfinal.core.Controller;
import com.zut.yanxin.dao.*;
import com.zut.yanxin.daoimpl.*;

public class RenderDataController extends Controller {
//返回所有院校列表
	public void renderUniList(){
		//解决跨域问题
		getResponse().addHeader("Access-Control-Allow-Origin", "*");
		UniversityDao uniDao = new UniversityDaoImpl();
		renderJson(uniDao.getAll());
	}
//根据条件筛选院校列表	
	public void renderUniListbyFiltrate(){
		getResponse().addHeader("Access-Control-Allow-Origin", "*");
		UniversityDao uniDao = new UniversityDaoImpl();
		renderJson(uniDao.getAllbyFiltrate(getPara("city"), getPara("is_211"), getPara("is_985"), getPara("is_graduate_school"), getPara("is_self_line")));
	}
//根据搜索框返回院校列表
	public void renderUniListbySearch(){
		getResponse().addHeader("Access-Control-Allow-Origin", "*");
		UniversityDao uniDao = new UniversityDaoImpl();
		renderJson(uniDao.getAllbySearch(getPara("keywords")));
	}
//返回招生简章信息
	public void renderRecListbyUniname(){
		getResponse().addHeader("Access-Control-Allow-Origin", "*");
		RecruitPageDao recDao = new RecruitPageDaoImpl();
		renderJson(recDao.getInfo(getPara("rec_uni_name")));
	}
//返回专业目录信息
	public void renderMajListbyUniname(){
		getResponse().addHeader("Access-Control-Allow-Origin", "*");
		MajorCatalogDao majDao = new MajorCatalogDaoImpl();
		renderJson(majDao.getInfo(getPara("maj_uni_name"),getPara("maj_college_name"),getPara("maj_name")));
	}
//返回每个学校的院系列表
	public void renderCollege(){
		getResponse().addHeader("Access-Control-Allow-Origin", "*");
		MajorCatalogDao majDao = new MajorCatalogDaoImpl();
		renderJson(majDao.getCollege(getPara("maj_uni_name")));
	}
//返回每个学校的院系列表
	public void renderMajor(){
		getResponse().addHeader("Access-Control-Allow-Origin", "*");
		MajorCatalogDao majDao = new MajorCatalogDaoImpl();
		renderJson(majDao.getMajor(getPara("maj_uni_name")));
	}
//返回研究方向信息
	public void renderRDList(){
		getResponse().addHeader("Access-Control-Allow-Origin", "*");
		ResearchDirectionDao resDao = new ResearchDirectionDaoImpl();
		renderJson(resDao.getRDInfo(getPara("res_uni_name"), getPara("res_college_name"), getPara("res_maj_name")));
	}
//返回考试范围信息
	public void renderExaList(){
		getResponse().addHeader("Access-Control-Allow-Origin", "*");
		ExamAreaDao exaDao = new ExamAreaDaoImpl();
		renderJson(exaDao.getInfo(getPara("exa_uni_name"), getPara("exa_college_name"), getPara("exa_maj_name")));
	}
//返回分数线信息
	public void renderScoList(){
		getResponse().addHeader("Access-Control-Allow-Origin", "*");
		ScoreLevelDao scoDao =new ScoreLevelDaoImpl();
		renderJson(scoDao.getInfo(getPara("sco_uni_name"),getPara("sco_college_name"),getPara("sco_maj_name")));
	}
//返回报录信息(renderRDList已经实现该功能)
	public void renderREList(){
		getResponse().addHeader("Access-Control-Allow-Origin", "*");
		ResearchDirectionDao resDao = new ResearchDirectionDaoImpl();
		renderJson(resDao.getREInfo(getPara("res_uni_name")));
	}
//返回某个院校专业的报录信息
	public void renderREList_Detail(){
		getResponse().addHeader("Access-Control-Allow-Origin", "*");
		ResearchDirectionDao resDao = new ResearchDirectionDaoImpl();
		renderJson(resDao.getRD_byYear(getPara("res_year"),getPara("res_uni_name"),getPara("res_college_name"),getPara("res_maj_name")));
	}
//根据学科类型返回专业列表
	public void renderMajbySubject(){
		getResponse().addHeader("Access-Control-Allow-Origin", "*");
		MajorCatalogDao majDao = new MajorCatalogDaoImpl();
		renderJson(majDao.getMajorwithLevel(getPara("maj_subject")));
	}
//根据专业检索院校信息
	public void renderUniAndMaj(){
		getResponse().addHeader("Access-Control-Allow-Origin", "*");
		UniAndMajDao umDao = new UniAndMajDaoImpl();
		renderJson(umDao.getInfo(getPara("maj_name")));
	}
}
