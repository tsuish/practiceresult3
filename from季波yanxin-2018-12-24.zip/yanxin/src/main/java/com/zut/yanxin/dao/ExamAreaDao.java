package com.zut.yanxin.dao;

import java.util.List;

import com.zut.yanxin.entity.ExamArea;

public interface ExamAreaDao {
//根据院校、学院、专业名称获取考试范围信息
	public List<ExamArea> getInfo(String exa_uni_name,String exa_college_name,String exa_maj_name);
}
