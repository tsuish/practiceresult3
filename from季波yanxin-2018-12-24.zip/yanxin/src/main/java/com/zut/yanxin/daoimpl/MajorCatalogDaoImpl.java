package com.zut.yanxin.daoimpl;

import java.util.ArrayList;
import java.util.List;

import com.jfinal.plugin.activerecord.Model;
import com.zut.yanxin.dao.MajorCatalogDao;
import com.zut.yanxin.entity.MajorCatalog;

public class MajorCatalogDaoImpl extends Model<MajorCatalogDaoImpl> implements MajorCatalogDao {

	private static final long serialVersionUID = 1L;
	public static final MajorCatalogDaoImpl dao = new MajorCatalogDaoImpl().dao();
	private static String sql = null;
	public static List<MajorCatalog> executeSql(String sql){
		List<MajorCatalog> list = new ArrayList<MajorCatalog>();
		List<MajorCatalogDaoImpl> DaoImplList = dao.find(sql);
		for(int i=0;i<DaoImplList.size();i++){
			int maj_id = DaoImplList.get(i).getInt("maj_id");
			String maj_year = DaoImplList.get(i).getStr("maj_year");
			String maj_code = DaoImplList.get(i).getStr("maj_code");
			String maj_name = DaoImplList.get(i).getStr("maj_name");
			String maj_college_name = DaoImplList.get(i).getStr("maj_college_name");
			String maj_uni_name = DaoImplList.get(i).getStr("maj_uni_name");
			String maj_academic = DaoImplList.get(i).getStr("maj_academic");
			int maj_system = DaoImplList.get(i).getInt("maj_system");
			boolean maj_transdisciplinary = DaoImplList.get(i).getBoolean("maj_transdisciplinary");
			String maj_level = DaoImplList.get(i).getStr("maj_level");
			String maj_subject = DaoImplList.get(i).getStr("maj_subject");
			list.add(new MajorCatalog(maj_id,maj_year,maj_code,maj_name,maj_college_name,maj_uni_name,maj_academic,maj_system,maj_transdisciplinary,maj_level,maj_subject));
		}
		return list;
	}
	@Override
	public List<MajorCatalog> getInfo(String maj_uni_name,String maj_college_name, String maj_name) {
		if(maj_uni_name!=null&&maj_college_name==null&&maj_name==null){
			//只根据学校进行筛选
			sql = "select * from major_catalog where maj_uni_name=\""+maj_uni_name+"\"";
		}else if(maj_uni_name!=null&&maj_college_name!=null&&maj_name==null){
			// 只选了院系名
			sql = "select * from major_catalog where maj_college_name=\""+maj_college_name+"\""+"and maj_uni_name=\""+maj_uni_name+"\"";
		}else if(maj_uni_name!=null&&maj_name!=null&&maj_college_name==null){
			//只选了专业名
			sql = "select * from major_catalog where maj_name=\""+maj_name+"\""+"and maj_uni_name=\""+maj_uni_name+"\"";
		}else if(maj_uni_name!=null&&maj_college_name!=null&&maj_name!=null){
			//都选了
			sql = "select * from major_catalog where maj_college_name=\""+maj_college_name+"\""+"and maj_name=\""+maj_name+"\""+"and maj_uni_name=\""+maj_uni_name+"\"";
		}
		return executeSql(sql);
	}
	@Override
	public List<String> getCollege(String maj_uni_name) {
		sql = "select distinct maj_college_name from major_catalog where maj_uni_name=\""+maj_uni_name+"\"";
		List<String> list = new ArrayList<String>();
		List<MajorCatalogDaoImpl> DaoImplList = dao.find(sql);
		for(int i=0;i<DaoImplList.size();i++){
			String maj_college_name = DaoImplList.get(i).getStr("maj_college_name");
			list.add(maj_college_name);
		}
		return list;
	}
	@Override
	public List<String> getMajor(String maj_uni_name) {
		sql = "select distinct maj_name from major_catalog where maj_uni_name=\""+maj_uni_name+"\"";
		List<String> list = new ArrayList<String>();
		List<MajorCatalogDaoImpl> DaoImplList = dao.find(sql);
		for(int i=0;i<DaoImplList.size();i++){
			String maj_name = DaoImplList.get(i).getStr("maj_name");
			list.add(maj_name);
		}
		return list;
	}
	@Override
	public List<String> getMajorwithLevel(String maj_subject) {
		sql = "select distinct maj_name from major_catalog where maj_subject=\""+maj_subject+"\""+"and maj_level  is not null";
		List<String> list = new ArrayList<String>();
		List<MajorCatalogDaoImpl> DaoImplList = dao.find(sql);
		for(int i=0;i<DaoImplList.size();i++){
			String maj_name = DaoImplList.get(i).getStr("maj_name");
			list.add(maj_name);
		}
		return list;
	}
}
