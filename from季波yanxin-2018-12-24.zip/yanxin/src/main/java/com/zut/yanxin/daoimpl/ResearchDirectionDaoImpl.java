package com.zut.yanxin.daoimpl;

import java.util.ArrayList;
import java.util.List;

import com.jfinal.plugin.activerecord.Model;
import com.zut.yanxin.dao.ResearchDirectionDao;
import com.zut.yanxin.entity.ResearchDirection;

public class ResearchDirectionDaoImpl extends Model<ResearchDirectionDaoImpl> implements ResearchDirectionDao {

	private static final long serialVersionUID = 1L;
	private static final ResearchDirectionDaoImpl dao = new ResearchDirectionDaoImpl().dao();
	private static String sql = null;
	
	public static List<ResearchDirection> executeSql(String sql){
		List<ResearchDirection> list = new ArrayList<ResearchDirection>();
		List<ResearchDirectionDaoImpl> DaoImplList = dao.find(sql);
		for(int i=0;i<DaoImplList.size();i++){
			int res_id = DaoImplList.get(i).getInt("res_id");
			String res_year = DaoImplList.get(i).getStr("res_year");
			String res_name = DaoImplList.get(i).getStr("res_name");
			String res_maj_name = DaoImplList.get(i).getStr("res_maj_name");
			String res_college_name = DaoImplList.get(i).getStr("res_college_name");
			String res_uni_name = DaoImplList.get(i).getStr("res_uni_name");
			String res_way = DaoImplList.get(i).getStr("res_way");
			int res_register_num = DaoImplList.get(i).getInt("res_register_num");
			int res_enroll_num = DaoImplList.get(i).getInt("res_enroll_num");
			int res_recommend_num = DaoImplList.get(i).getInt("res_recommend_num");
			list.add(new ResearchDirection(res_id,res_year,res_name,res_maj_name,res_college_name,res_uni_name,res_way,res_register_num,res_enroll_num,res_recommend_num));
		}
		return list;
	}
	
	
	@Override
	public List<ResearchDirection> getRDInfo(String res_uni_name, String res_college_name, String res_maj_name) {
		if(res_uni_name!=null&&res_college_name!=null&&res_maj_name!=null){
			//都选
			sql = "select * from research_direction where res_uni_name=\""+res_uni_name+"\""+"and res_college_name=\""+res_college_name+"\""+"and res_maj_name=\""+res_maj_name+"\"";
		}else if(res_uni_name!=null&&res_college_name!=null&&res_maj_name==null){
			//只选择院系
			sql = "select * from research_direction where res_uni_name=\""+res_uni_name+"\""+"and res_college_name=\""+res_college_name+"\"";
		}else if(res_uni_name!=null&&res_college_name==null&&res_maj_name!=null){
			//只选择专业
			sql = "select * from research_direction where res_uni_name=\""+res_uni_name+"\""+"and res_maj_name=\""+res_maj_name+"\"";
		}else if(res_uni_name!=null&&res_college_name==null&&res_maj_name==null){
		//都不选
			sql = "select * from research_direction where res_uni_name=\""+res_uni_name+"\"";
		}
		return executeSql(sql);
	}
	@Override
	public List<ResearchDirection> getREInfo(String res_uni_name) {
		sql = "select * from research_direction where res_uni_name=\""+res_uni_name+"\"";
		return executeSql(sql);
	}

	@Override
	public List<ResearchDirection> getRD_byYear(String res_year, String res_uni_name, String res_college_name,
			String res_maj_name) {
		// TODO Auto-generated method stub
		if(res_year!=null&&res_uni_name!=null&&res_college_name!=null&&res_maj_name!=null){
			//都选
			sql = "select * from research_direction where res_uni_name=\""+res_uni_name+"\""+"and res_college_name=\""+res_college_name+"\""+"and res_maj_name=\""+res_maj_name+"\""+"and res_year=\""+res_year+"\"";
		}else if(res_year!=null&&res_uni_name!=null&&res_college_name!=null&&res_maj_name==null){
			//只选择院系
			sql = "select * from research_direction where res_uni_name=\""+res_uni_name+"\""+"and res_college_name=\""+res_college_name+"\""+"and res_year=\""+res_year+"\"";
		}else if(res_year!=null&&res_uni_name!=null&&res_college_name==null&&res_maj_name!=null){
			//只选择专业
			sql = "select * from research_direction where res_uni_name=\""+res_uni_name+"\""+"and res_maj_name=\""+res_maj_name+"\""+"and res_year=\""+res_year+"\"";
		}else if(res_year!=null&&res_uni_name!=null&&res_college_name==null&&res_maj_name==null){
			//只选择年份
			sql = "select * from research_direction where res_uni_name=\""+res_uni_name+"\""+"and res_year=\""+res_year+"\"";
		}else if(res_year!=null&&res_uni_name!=null&&res_college_name==null&&res_maj_name==null){
		//都不选
			sql = "select * from research_direction where res_uni_name=\""+res_uni_name+"\""+"and res_year=\""+res_year+"\"";
		}else if(res_year==null&&res_uni_name!=null&&res_college_name!=null&&res_maj_name!=null){
			sql = "select * from research_direction where res_uni_name=\""+res_uni_name+"\""+"and res_college_name=\""+res_college_name+"\""+"and res_maj_name=\""+res_maj_name+"\"";
		}else if(res_year==null&&res_uni_name!=null&&res_college_name==null&&res_maj_name!=null){
			sql = "select * from research_direction where res_uni_name=\""+res_uni_name+"\""+"and res_maj_name=\""+res_maj_name+"\"";
		}else if(res_year==null&&res_uni_name!=null&&res_college_name==null&&res_maj_name==null){
			sql = "select * from research_direction where res_uni_name=\""+res_uni_name+"\"";
		}
		return executeSql(sql);
	}

}
