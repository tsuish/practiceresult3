package com.zut.yanxin.daoimpl;

import java.util.ArrayList;
import java.util.List;

import com.jfinal.plugin.activerecord.Model;
import com.zut.yanxin.dao.RecruitPageDao;
import com.zut.yanxin.entity.RecruitPage;

public class RecruitPageDaoImpl extends Model<RecruitPageDaoImpl> implements RecruitPageDao {

	private static final long serialVersionUID = 1L;

	private static final RecruitPageDaoImpl dao = new RecruitPageDaoImpl().dao();
	private static String sql = null;
	@Override
	public List<RecruitPage> getInfo(String rec_uni_name) {
		sql = "select * from recruit_page where rec_uni_name=\""+rec_uni_name+"\"";
		List<RecruitPage> list = new ArrayList<RecruitPage>();
		List<RecruitPageDaoImpl> DaoImplList = dao.find(sql);
		for(int i=0;i<DaoImplList.size();i++){
			int rec_id = DaoImplList.get(i).getInt("rec_id");
			String rec_year = DaoImplList.get(i).getStr("rec_year");
			String rec_content = DaoImplList.get(i).getStr("rec_content");
			list.add(new RecruitPage(rec_id,rec_year,rec_content,rec_uni_name));
		}
		return list;
	}

}
