package com.zut.yanxin.entity;

public class ScoreLevel {
private int sco_id;
private String sco_year;
private String sco_maj_name;
private String sco_college_name;
private String sco_uni_name;
private int sco_country_line;
private int sco_self_line;
private int sco_reexamine_line;
private int sco_subject1;
private int sco_subject2;
private int sco_subject3;
private int sco_subject4;
public ScoreLevel(int sco_id, String sco_year, String sco_maj_name, String sco_college_name, String sco_uni_name,
		int sco_country_line, int sco_self_line, int sco_reexamine_line, int sco_subject1, int sco_subject2,
		int sco_subject3, int sco_subject4) {
	super();
	this.sco_id = sco_id;
	this.sco_year = sco_year;
	this.sco_maj_name = sco_maj_name;
	this.sco_college_name = sco_college_name;
	this.sco_uni_name = sco_uni_name;
	this.sco_country_line = sco_country_line;
	this.sco_self_line = sco_self_line;
	this.sco_reexamine_line = sco_reexamine_line;
	this.sco_subject1 = sco_subject1;
	this.sco_subject2 = sco_subject2;
	this.sco_subject3 = sco_subject3;
	this.sco_subject4 = sco_subject4;
}
public int getSco_id() {
	return sco_id;
}
public void setSco_id(int sco_id) {
	this.sco_id = sco_id;
}
public String getSco_year() {
	return sco_year;
}
public void setSco_year(String sco_year) {
	this.sco_year = sco_year;
}
public String getSco_maj_name() {
	return sco_maj_name;
}
public void setSco_maj_name(String sco_maj_name) {
	this.sco_maj_name = sco_maj_name;
}
public String getSco_college_name() {
	return sco_college_name;
}
public void setSco_college_name(String sco_college_name) {
	this.sco_college_name = sco_college_name;
}
public String getSco_uni_name() {
	return sco_uni_name;
}
public void setSco_uni_name(String sco_uni_name) {
	this.sco_uni_name = sco_uni_name;
}
public int getSco_country_line() {
	return sco_country_line;
}
public void setSco_country_line(int sco_country_line) {
	this.sco_country_line = sco_country_line;
}
public int getSco_self_line() {
	return sco_self_line;
}
public void setSco_self_line(int sco_self_line) {
	this.sco_self_line = sco_self_line;
}
public int getSco_reexamine_line() {
	return sco_reexamine_line;
}
public void setSco_reexamine_line(int sco_reexamine_line) {
	this.sco_reexamine_line = sco_reexamine_line;
}
public int getSco_subject1() {
	return sco_subject1;
}
public void setSco_subject1(int sco_subject1) {
	this.sco_subject1 = sco_subject1;
}
public int getSco_subject2() {
	return sco_subject2;
}
public void setSco_subject2(int sco_subject2) {
	this.sco_subject2 = sco_subject2;
}
public int getSco_subject3() {
	return sco_subject3;
}
public void setSco_subject3(int sco_subject3) {
	this.sco_subject3 = sco_subject3;
}
public int getSco_subject4() {
	return sco_subject4;
}
public void setSco_subject4(int sco_subject4) {
	this.sco_subject4 = sco_subject4;
}

}
