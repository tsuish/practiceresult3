package com.zut.yanxin.daoimpl;

import java.util.ArrayList;
import java.util.List;

import com.jfinal.plugin.activerecord.Model;
import com.zut.yanxin.dao.ScoreLevelDao;
import com.zut.yanxin.entity.ScoreLevel;

public class ScoreLevelDaoImpl extends Model<ScoreLevelDaoImpl> implements ScoreLevelDao {

	private static final long serialVersionUID = 1L;
	private static final ScoreLevelDaoImpl dao = new ScoreLevelDaoImpl().dao();
	private static String sql = null;
	public static List<ScoreLevel> executeSql(String sql){
		List<ScoreLevel> list = new ArrayList<ScoreLevel>();
		List<ScoreLevelDaoImpl> DaoImplList = dao.find(sql);
		for(int i=0;i<DaoImplList.size();i++){
			int sco_id = DaoImplList.get(i).getInt("sco_id");
			String sco_year = DaoImplList.get(i).getStr("sco_year");
			String sco_maj_name = DaoImplList.get(i).getStr("sco_maj_name");
			String sco_college_name = DaoImplList.get(i).getStr("sco_college_name");
			String sco_uni_name = DaoImplList.get(i).getStr("sco_uni_name");
			int sco_country_line = DaoImplList.get(i).getInt("sco_country_line");
			int sco_self_line = DaoImplList.get(i).getInt("sco_self_line");
			int sco_reexamine_line = DaoImplList.get(i).getInt("sco_reexamine_line");
			int sco_subject1 = DaoImplList.get(i).getInt("sco_subject1");
			int sco_subject2 = DaoImplList.get(i).getInt("sco_subject2");
			int sco_subject3 = DaoImplList.get(i).getInt("sco_subject3");
			int sco_subject4 = DaoImplList.get(i).getInt("sco_subject4");
			list.add(new ScoreLevel(sco_id,sco_year,sco_maj_name,sco_college_name,sco_uni_name,sco_country_line,sco_self_line,sco_reexamine_line,sco_subject1,sco_subject2,sco_subject3,sco_subject4));
		}
		return list;
	}
	@Override
	public List<ScoreLevel> getInfo(String sco_uni_name,String sco_college_name,String sco_maj_name) {
		if(sco_uni_name!=null&&sco_college_name==null&&sco_maj_name==null){
			//都不选
			sql = "select * from score_level where sco_uni_name=\""+sco_uni_name+"\"";
		}else if(sco_uni_name!=null&&sco_college_name!=null&&sco_maj_name==null){
			//选择院系
			sql = "select * from score_level where sco_uni_name=\""+sco_uni_name+"\""+"and sco_college_name=\""+sco_college_name+"\"";
		}else if(sco_uni_name!=null&&sco_college_name==null&&sco_maj_name!=null){
			//选择专业
			sql = "select * from score_level where sco_uni_name=\""+sco_uni_name+"\""+"and sco_maj_name=\""+sco_maj_name+"\"";
		}else if(sco_uni_name!=null&&sco_college_name!=null&&sco_maj_name!=null){
			//都选
			sql = "select * from score_level where sco_uni_name=\""+sco_uni_name+"\""+"and sco_college_name=\""+sco_college_name+"\""+"and sco_maj_name=\""+sco_maj_name+"\"";
		}
		return executeSql(sql);
	}

}
