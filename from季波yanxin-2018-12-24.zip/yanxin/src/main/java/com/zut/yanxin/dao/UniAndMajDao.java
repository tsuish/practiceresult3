package com.zut.yanxin.dao;

import java.util.List;

import com.zut.yanxin.entity.UniAndMaj;

public interface UniAndMajDao {
//返回根据专业检索后的院校信息
public List<UniAndMaj> getInfo(String maj_name);
}
