package com.zut.yanxin.dao;

import java.util.List;

import com.zut.yanxin.entity.RecruitPage;

public interface RecruitPageDao {
	//根据院校名称获取招生简章信息
	public List<RecruitPage> getInfo(String rec_uni_name);
}
