package com.zut.yanxin.daoimpl;

import java.util.ArrayList;
import java.util.List;

import com.zut.yanxin.dao.UniAndMajDao;
import com.zut.yanxin.entity.UniAndMaj;

public class UniAndMajDaoImpl  implements UniAndMajDao {
	private static String sql=null;
	public static List<UniAndMaj> executeSql(String sql){
		List<UniAndMaj> list = new ArrayList<UniAndMaj>();
		List<UniversityDaoImpl> DaoImplList = UniversityDaoImpl.dao.find(sql);
		for(int i=0;i<DaoImplList.size();i++){
			String uni_code = DaoImplList.get(i).getStr("uni_code");
			String uni_name = DaoImplList.get(i).getStr("uni_name");
			String uni_location = DaoImplList.get(i).getStr("uni_location");
			String uni_subjection = DaoImplList.get(i).getStr("uni_subjection");
			String uni_characteristic = DaoImplList.get(i).getStr("uni_characteristic");
			String maj_level = DaoImplList.get(i).getStr("maj_level");
			list.add(new UniAndMaj(uni_code,uni_name,uni_location,uni_subjection,uni_characteristic,maj_level));
		}
		return list;
	}
	@Override
	public List<UniAndMaj> getInfo(String maj_name) {
		//inner join联表查询，查询结果以A+、A、A-...的顺序排序
		sql = "select distinct uni_code,uni_name,uni_location,uni_subjection,uni_characteristic,maj_level from university inner join major_catalog on maj_name=\""+maj_name+"\""+"and maj_uni_name=uni_name and maj_level is not null"
		+" order by case "
		+ "when maj_level='A+' then 1 "
		+ "when maj_level='A'   then 2 "
		+ "when maj_level='A-'  then 3 "
		+ "when maj_level='B+' then 4 "
		+ "when maj_level='B'    then 5 "
		+ "when maj_level='B-'  then 6 "
		+ "when maj_level='C+' then 7 "
		+ "when maj_level='C'   then 8 "
		+ "when maj_level='C-' then 9 "
		+ "end asc";
		return executeSql(sql);
	}

}
