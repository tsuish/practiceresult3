package com.zut.yanxin.dao;

import java.util.List;

import com.zut.yanxin.entity.MajorCatalog;

public interface MajorCatalogDao {
//根据院校名称获取所有专业信息
	public List<MajorCatalog> getInfo(String maj_uni_name,String maj_college_name,String maj_name);
//返回院系列表
	public List<String> getCollege(String maj_uni_name);
//返回专业列表
	public List<String> getMajor(String maj_uni_name);
//根据学科类型返回对应的专业目录(有学科评估等级)
	public List<String> getMajorwithLevel(String maj_subject);
}
