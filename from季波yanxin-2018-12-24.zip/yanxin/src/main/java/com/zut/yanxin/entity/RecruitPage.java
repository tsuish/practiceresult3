package com.zut.yanxin.entity;

public class RecruitPage {
private int rec_id;
private String rec_year;
private String rec_content;
private String uni_name;
public RecruitPage(int rec_id, String rec_year, String rec_content, String uni_name) {
	super();
	this.rec_id = rec_id;
	this.rec_year = rec_year;
	this.rec_content = rec_content;
	this.uni_name = uni_name;
}
public int getRec_id() {
	return rec_id;
}
public void setRec_id(int rec_id) {
	this.rec_id = rec_id;
}
public String getRec_year() {
	return rec_year;
}
public void setRec_year(String rec_year) {
	this.rec_year = rec_year;
}
public String getRec_content() {
	return rec_content;
}
public void setRec_content(String rec_content) {
	this.rec_content = rec_content;
}
public String getUni_name() {
	return uni_name;
}
public void setUni_name(String uni_name) {
	this.uni_name = uni_name;
}
}
