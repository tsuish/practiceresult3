package com.zut.yanxin.daoimpl;

import java.util.ArrayList;
import java.util.List;

import com.jfinal.plugin.activerecord.Model;
import com.zut.yanxin.dao.ExamAreaDao;
import com.zut.yanxin.entity.ExamArea;

public class ExamAreaDaoImpl extends Model<ExamAreaDaoImpl> implements ExamAreaDao {

	private static final long serialVersionUID = 1L;
	private static final ExamAreaDaoImpl dao = new ExamAreaDaoImpl().dao();
	private static String sql = null;
	@Override
	public List<ExamArea> getInfo(String exa_uni_name, String exa_college_name, String exa_maj_name) {
		sql = "select * from exam_area where exa_uni_name=\""+exa_uni_name+"\""+"and exa_college_name=\""+exa_college_name+"\""+"and exa_maj_name=\""+exa_maj_name+"\"";
		List<ExamArea> list = new ArrayList<ExamArea>();
		List<ExamAreaDaoImpl> DaoImplList = dao.find(sql);
		for(int i=0;i<DaoImplList.size();i++){
			int exa_id = DaoImplList.get(i).getInt("exa_id");
			String exa_year = DaoImplList.get(i).getStr("exa_year");
			String exa_subject1 = DaoImplList.get(i).getStr("exa_subject1");
			String exa_subject2 = DaoImplList.get(i).getStr("exa_subject2");
			String exa_subject3 = DaoImplList.get(i).getStr("exa_subject3");
			String exa_subject4 = DaoImplList.get(i).getStr("exa_subject4");
			list.add(new ExamArea(exa_id,exa_year,exa_maj_name,exa_college_name,exa_uni_name,exa_subject1,exa_subject2,exa_subject3,exa_subject4));
		}
		return list;
	}

}
