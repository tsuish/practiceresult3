package com.zut.yanxin.entity;

public class University {
private int uni_id;
private String uni_code;
private String uni_name;
private String uni_location;
private String uni_subjection;
private String uni_characteristic;
private boolean uni_graduate_school;
private boolean uni_self_line;
public University(int uni_id, String uni_code, String uni_name, String uni_location, String uni_subjection,
		String uni_characteristic, boolean uni_graduate_school, boolean uni_self_line) {
	super();
	this.uni_id = uni_id;
	this.uni_code = uni_code;
	this.uni_name = uni_name;
	this.uni_location = uni_location;
	this.uni_subjection = uni_subjection;
	this.uni_characteristic = uni_characteristic;
	this.uni_graduate_school = uni_graduate_school;
	this.uni_self_line = uni_self_line;
}
public int getUni_id() {
	return uni_id;
}
public void setUni_id(int uni_id) {
	this.uni_id = uni_id;
}
public String getUni_code() {
	return uni_code;
}
public void setUni_code(String uni_code) {
	this.uni_code = uni_code;
}
public String getUni_name() {
	return uni_name;
}
public void setUni_name(String uni_name) {
	this.uni_name = uni_name;
}
public String getUni_location() {
	return uni_location;
}
public void setUni_location(String uni_location) {
	this.uni_location = uni_location;
}
public String getUni_subjection() {
	return uni_subjection;
}
public void setUni_subjection(String uni_subjection) {
	this.uni_subjection = uni_subjection;
}
public String getUni_characteristic() {
	return uni_characteristic;
}
public void setUni_characteristic(String uni_characteristic) {
	this.uni_characteristic = uni_characteristic;
}
public boolean isUni_graduate_school() {
	return uni_graduate_school;
}
public void setUni_graduate_school(boolean uni_graduate_school) {
	this.uni_graduate_school = uni_graduate_school;
}
public boolean isUni_self_line() {
	return uni_self_line;
}
public void setUni_self_line(boolean uni_self_line) {
	this.uni_self_line = uni_self_line;
}
}
