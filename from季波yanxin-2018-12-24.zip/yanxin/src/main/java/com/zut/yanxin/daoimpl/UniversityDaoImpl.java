package com.zut.yanxin.daoimpl;

import java.util.ArrayList;
import java.util.List;

import com.jfinal.plugin.activerecord.Model;
import com.zut.yanxin.dao.UniversityDao;
import com.zut.yanxin.entity.*;

public class UniversityDaoImpl extends Model<UniversityDaoImpl> implements UniversityDao  {
	//进行序列化
	private static final long serialVersionUID = 1L;
	//创建数据访问对象
	public static final UniversityDaoImpl dao = new UniversityDaoImpl().dao();
	//定义sql为空字符串
	private static String sql=null;
	
	public static List<University> executeSql(String sql){
		//创建空集合存储University对象
		List<University> list = new ArrayList<University>();
		//执行sql返回数据
		List<UniversityDaoImpl> DaoImplList = dao.find(sql);
		//循环遍历并将数据进行封装
		for(int i=0;i<DaoImplList.size();i++){
			int uni_id = DaoImplList.get(i).getInt("uni_id");
			String uni_code = DaoImplList.get(i).getStr("uni_code");
			String uni_name = DaoImplList.get(i).getStr("uni_name");
			String uni_location = DaoImplList.get(i).getStr("uni_location");
			String uni_subjection = DaoImplList.get(i).getStr("uni_subjection");
			String uni_characteristic = DaoImplList.get(i).getStr("uni_characteristic");
			boolean uni_graduate_school = DaoImplList.get(i).getBoolean("uni_graduate_school");
			boolean uni_self_line = DaoImplList.get(i).getBoolean("uni_self_line");
			list.add(new University(uni_id,uni_code,uni_name,uni_location,uni_subjection,uni_characteristic,uni_graduate_school,uni_self_line));
		}
		return list;
}
	
	@Override
	public List<University> getAll() {
		sql = "select * from university";
		return executeSql(sql);
	}

	@Override
	public List<University> getAllbySearch(String keywords) {
		sql = "select * from university where uni_name like '%"+keywords+"%' ";
		return executeSql(sql);
	}

	@Override
	public List<University> getAllbyFiltrate(String city, String is_211, String is_985, String is_graduate_school,
			String is_self_line) {
		if(city.equals("")){
			city = "%%";
		}
		if(is_211!=null&&is_985!=null&&is_graduate_school!=null&&is_self_line!=null){
			//全部勾选
			sql = "select * from university where uni_location like \""+city+"\"and uni_characteristic like '%985%' and uni_graduate_school=1 and uni_self_line=1";
		}else if(is_211==null&&is_985!=null&&is_graduate_school!=null&&is_self_line!=null){
			//除了211没勾选
			sql = "select * from university where uni_location like \""+city+"\"and uni_characteristic like '%985%' and uni_graduate_school=1 and uni_self_line=1";
		}else if(is_211!=null&&is_985==null&&is_graduate_school!=null&&is_self_line!=null){
			//除了985没勾选
			sql = "select * from university where uni_location like \""+city+"\"and uni_characteristic ='211' and uni_graduate_school=1 and uni_self_line=1 ";
		}else if(is_211!=null&&is_985!=null&&is_graduate_school==null&&is_self_line!=null){
			//除了研究生院没勾选
			sql = "select * from university where uni_location like \""+city+"\"and uni_characteristic like '%985%'  and uni_self_line=1";
		}else if(is_211!=null&&is_985!=null&&is_graduate_school!=null&&is_self_line==null){
			//除了自划线没勾选
			sql = "select * from university where uni_location like \""+city+"\"and uni_characteristic like '%985%'  and uni_graduate_school=1";
		}else if(is_211!=null&&is_985!=null&&is_graduate_school==null&&is_self_line==null){
			//勾选了211和985
			sql = "select * from university where uni_location like \""+city+"\"and uni_characteristic like '%985%' ";
		}else if(is_211!=null&&is_985==null&&is_graduate_school!=null&&is_self_line==null){
			//勾选了211和研究生院
			sql = "select * from university where uni_location like \""+city+"\"and uni_characteristic = '211'  and uni_graduate_school=1";
		}else if(is_211!=null&&is_985==null&&is_graduate_school==null&&is_self_line!=null){
			//勾选了211和自划线
			sql = "select * from university where uni_location like \""+city+"\"and uni_characteristic = '211'  and uni_self_line=1";
		}else if(is_211==null&&is_985!=null&&is_graduate_school!=null&&is_self_line==null){
			//勾选了985和研究生院
			sql = "select * from university where uni_location like \""+city+"\"and uni_characteristic like '%985%'  and uni_graduate_school=1";
		}else if(is_211==null&&is_985!=null&&is_graduate_school==null&&is_self_line!=null){
			//勾选了985和自划线
			sql = "select * from university where uni_location like \""+city+"\"and uni_characteristic like '%985%'  and uni_self_line=1";
		}else if(is_211==null&&is_985==null&&is_graduate_school!=null&&is_self_line!=null){
			//勾选了自划线和研究生院
			sql = "select * from university where uni_location like \""+city+"\" and uni_graduate_school=1 and uni_self_line=1 ";
		}else if(is_211!=null&&is_985==null&&is_graduate_school==null&&is_self_line==null){
			//只勾选211
			sql = "select * from university where uni_location like \""+city+"\"and uni_characteristic = '211' ";
		}else if(is_211==null&&is_985!=null&&is_graduate_school==null&&is_self_line==null){
			//只勾选985
			sql = "select * from university where uni_location like \""+city+"\"and uni_characteristic like '%985%' ";
		}else if(is_211==null&&is_985==null&&is_graduate_school!=null&&is_self_line==null){
			//只勾选研究生院
			sql = "select * from university where uni_location like \""+city+"\" and uni_graduate_school=1 ";
		}else if(is_211==null&&is_985==null&&is_graduate_school==null&&is_self_line!=null){
			//只勾选自划线
			sql = "select * from university where uni_location like \""+city+"\" and uni_self_line=1 ";
		}else{
			//都不勾选
			sql = "select * from university where uni_location like \""+city+"\"";
		}
		return executeSql(sql);
	}
	
	

}
