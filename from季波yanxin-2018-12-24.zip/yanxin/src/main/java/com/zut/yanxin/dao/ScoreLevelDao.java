package com.zut.yanxin.dao;

import java.util.List;

import com.zut.yanxin.entity.ScoreLevel;

public interface ScoreLevelDao {
//根据院校名查分数信息
	public List<ScoreLevel> getInfo(String sco_uni_name,String sco_college_name,String sco_maj_name);
}
