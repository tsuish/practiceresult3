package com.zut.yanxin.entity;

public class UniAndMaj {
private String uni_code;
private String uni_name;
private String uni_location;
private String uni_subjection;
private String uni_characteristic;
private String maj_level;
public UniAndMaj(String uni_code, String uni_name, String uni_location, String uni_subjection,
		String uni_characteristic, String maj_level) {
	super();
	this.uni_code = uni_code;
	this.uni_name = uni_name;
	this.uni_location = uni_location;
	this.uni_subjection = uni_subjection;
	this.uni_characteristic = uni_characteristic;
	this.maj_level = maj_level;
}
public String getUni_code() {
	return uni_code;
}
public void setUni_code(String uni_code) {
	this.uni_code = uni_code;
}
public String getUni_name() {
	return uni_name;
}
public void setUni_name(String uni_name) {
	this.uni_name = uni_name;
}
public String getUni_location() {
	return uni_location;
}
public void setUni_location(String uni_location) {
	this.uni_location = uni_location;
}
public String getUni_subjection() {
	return uni_subjection;
}
public void setUni_subjection(String uni_subjection) {
	this.uni_subjection = uni_subjection;
}
public String getUni_characteristic() {
	return uni_characteristic;
}
public void setUni_characteristic(String uni_characteristic) {
	this.uni_characteristic = uni_characteristic;
}
public String getMaj_level() {
	return maj_level;
}
public void setMaj_level(String maj_level) {
	this.maj_level = maj_level;
}
}
