window.onload = function() {
	//初始化侧边栏的高度
	sidebar_init();
	//设置index_university_name为第一个页面传过来的学校名称
	set_index_university_name_from_page_one();
	
	//给sidebar绑定事件
	sidebar_bind_event();
	//给表格绑定事件
	table_bind_event();
	//给表头绑定事件
	th_college_major_bind_event();
}

//初始化侧边栏的高度	
function sidebar_init(){
	// 获得屏幕的高度
	// 获得侧边栏控件
	// 设置侧边栏控件的高度
	var height = window.screen.height;
	var sidebar = document.getElementById("sidebar");
	sidebar.style.top = height*0.3+'px';
}

//获得从第一个页面传过来的参数：学校名称,根据参数类型来选择初始化显示页面为专业目录还是招生简章
function set_index_university_name_from_page_one() {
	var parameters = location.search;
  	if ( parameters.indexOf( "?" ) != -1 ) {
    	var parameter = parameters.substr( 1 ); //substr()方法返回从参数值开始到结束的字符串；
    	var strs = parameter.split( "&");
    	//得到院校名称
    	var str = strs[0];
    	var uni_name = str.split("=")[1];
    	//把index中的uni_name改成该学校的名称
		get_index_uni_name_element().innerText = decodeURI(uni_name);
    	//得到详细,用来判断是否是在
    	var detail = strs[1].split("=")[1];
    	if(detail == "1"){
    		//获取专业目录并将相关数据插入到页面中
			get_major_and_insert_to_page();
    	}else {
    		//招生简章
			get_enrollment_and_insert_to_page();		
    	}
  	}
}
//获得index中的学校名称元素a
function get_index_uni_name_element() {
	return document.getElementById("uni_name");
}
//获得要插入的生成内容的位置
function get_content_element() {
	return document.getElementById("content");
}
//删除页面中已有内容
//参数：content元素
function delete_content(content) {
	var content_child = content.children;
	for (var i = content_child.length - 1; i >=0; i--) {
		content.removeChild(content_child[i]);
	}

}
///////////////////////////////////考试范围相关函数开始///////////////////////////////////////

//获取考试范围标签
function get_exam_scope_element(){
	return document.getElementsByName("exam_scope");
}
//绑定考试范围事件
function exam_scope_bind_event(){
	var exam_scopes = get_exam_scope_element();
	for (var i = 0; i < exam_scopes.length; i++) {
		exam_scopes[i].onclick = exam_scope_onclick;
	}
}
//考试范围点击事件
function exam_scope_onclick(){
	//获取要插入的位置
	var content = get_content_element();
	//获取学校名称、学院名称、专业名称
	var uni_name = get_index_uni_name_element().innerText;
	//获取学院名称
	var college_name = get_maj_college_name_element().innerText;
	//获取专业名称
	var maj_name = get_maj_name_element().innerText;

	//拼接URL
	var URL = "http://39.105.39.215:8080/yanxin/renderdata/renderExaList?exa_uni_name="+uni_name+"&exa_college_name="+college_name+"&exa_maj_name="+maj_name;
	var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange=function()
	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200){


			var txt = xmlhttp.responseText;
			var inner = '<div>';

		    var obj = eval ("(" + txt + ")");
		   	for (var i = 0; i < obj.length; i++) {
		   		if(obj[i].exa_subject2 != "" && obj[i].exa_subject2 != null){
		   			inner +='<h2 class="text_white">年份：'+obj[i].exa_year+'</h2>'+
					'<p class="text_white">业务课一：'+obj[i].exa_subject1+'</p>'+
					'<p class="text_white">业务课二：'+obj[i].exa_subject2+'</p>'+
					'<p class="text_white">业务课三：'+obj[i].exa_subject3+'</p>'+
					'<p class="text_white">业务课四：'+obj[i].exa_subject4+'</p>';
		   		}else {
		   			inner +='<h2 class="text_white">年份：'+obj[i].exa_year+'</h2>'+
					'<p class="text_white">考试范围：'+obj[i].exa_subject1+'</p>';
		   		}
		   	}
		   	inner += '</div>';
		    content.innerHTML = inner;
		}
	}
	xmlhttp.open("GET",URL,true);
	xmlhttp.send();
}

///////////////////////////////////考试范围相关函数结束///////////////////////////////////////
///////////////////////////////////研究方向相关函数开始///////////////////////////////////////
//获取研究方向标签
function get_research_direction_element(){
	return document.getElementsByName("research_direction");
}
//绑定研究方向事件
function research_direction_bind_event(){
	var research_direction_elements = get_research_direction_element();
	for (var i = 0; i < research_direction_elements.length; i++) {
		research_direction_elements[i].onclick = research_direction_onclick;
	}
}
//获取学院名称
function get_maj_college_name_element(){
	if(event.srcElement.tagName == "A"){
		var tr = event.srcElement.parentNode.parentNode;
		var tds = tr.children;
		return tds[1];
	}
}
//获取专业名称
function get_maj_name_element(){
	if(event.srcElement.tagName == "A"){
		var tr = event.srcElement.parentNode.parentNode;
		var tds = tr.children;
		return tds[2];
	}
}
//点击研究方向事件
function research_direction_onclick(){
	//哈哈哈
	//获取要插入的位置
	var content = get_content_element();
	//获取学校名称
	var uni_name = get_index_uni_name_element().innerText;
	//获取学院名称
	var maj_college_name = get_maj_college_name_element().innerText;
	//获取专业名称
	var maj_name = get_maj_name_element().innerText;
	//拼接URL
	var URL = "http://39.105.39.215:8080/yanxin/renderdata/renderRDList?res_uni_name="+uni_name+"&res_college_name="+maj_college_name+"&res_maj_name="+maj_name;
	var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange=function()
	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200){
			var txt = xmlhttp.responseText;
			var inner = '<table>'+
      				'<tr>'+
        				'<th>年份</th>'+
        				'<th>方向名称</th>'+
        				'<th>所属专业</th>'+
        				'<th>学习方式</th>'+
        				'<th>指导教师</th>'+
      				'</tr>';
		    var obj = eval ("(" + txt + ")");
		   	for (var i = 0; i < obj.length; i++) {
		   		inner += '<tr>'+
    					'<td>'+obj[i].res_year+'</td>'+
    					'<td>'+obj[i].res_name+'</td>'+
    					'<td>'+obj[i].res_maj_name+'</td>'+
    					'<td>'+obj[i].res_way+'</td>'+
    					'<td><a href="#">详情</a></td>'+
    				'</tr>';
		   	}
		   	inner += '</table>';
		    content.innerHTML = inner;
		}
	}
	xmlhttp.open("GET",URL,true);
	xmlhttp.send();	
}
///////////////////////////////////研究方向相关函数结束///////////////////////////////////////
//////////////////////////table有关函数开始//////////////////////////////////////
//得到tr
function get_trs(){
	return document.getElementsByTagName("TR");
}
//表格事件的绑定
function table_bind_event(){
	var trs = get_trs();
	for(var i=1; i<trs.length; i++){
		trs[i].onmouseover = trs_onmouseover;
		trs[i].onmouseout = trs_onmouseout;
	}
}
//表格中的鼠标悬浮离开事件
function trs_onmouseout(){
	var td;
	var tr;
	if(event.srcElement.tagName == "A"){
		td = event.srcElement.parentNode;
	}else {
		td = event.srcElement;
	} 
	tr = td.parentNode;
	tr.style.backgroundColor  = 'white';
}
//表格中的行鼠标悬浮事件
function trs_onmouseover(){
	var td;
	var tr;
	if(event.srcElement.tagName == "A"){
		td = event.srcElement.parentNode;
	}else {
		td = event.srcElement;	
	}
	tr = td.parentNode;
	tr.style.backgroundColor  = '#808080';
}
//得到表头中的院系
function get_college_element() {
	return document.getElementById("college");
}
//得到表头中的专业
function get_major_element() {
	return document.getElementById("major");
}
//给表头中的院系和专业绑定点击和事件
function th_college_major_bind_event() {
	var college_element = get_college_element();
	var major_element = get_major_element();

	college_element.onmouseover = college_element_onmouseover;	
	major_element.onmouseover = major_element_onmouseover;

	college_element.onclick = college_element_onclick;
	major_element.onclick = major_element_onclick;
}

//表头中院系鼠标悬浮事件
function college_element_onmouseover() {
	if(event.srcElement && event.srcElement.tagName=="TH"){
		var college_element = event.srcElement;
		college_element.style.cursor ='pointer';
	}	
}
//表头中专业鼠标悬浮事件
function major_element_onmouseover() {
	if(event.srcElement && event.srcElement.tagName=="TH"){
		var major_element = event.srcElement;
		major_element.style.cursor ='pointer';
	}
}
//正在写的地方
//向后台发送数据，获取表头中的院系列表
function get_college_select(){}
//向后台发送请求，获取表头中的专业列表
function get_major_select(){}
//表头中院系点击事件
function college_element_onclick(select) {
	var select = '<select>'+
					'<option>院系</option>'+
					'<option>全部</option>'+
					'<option>马克思主义学院</option>'+
					'<option>经济管理学院</option>'+
				 '</select>';
	if(event.srcElement && event.srcElement.tagName=="TH"){
		var college_element = event.srcElement;
		//删除表头院系中原本存在的文本
		college_element.innerText = "";
		//将生成的select标签插入到表头院系中
		college_element.innerHTML = select;
		//院系select事件绑定
		college_select_bind_event();
	}
}
//表头中专业点击事件
function major_element_onclick(select) {
	var select = '<select>'+
					'<option>专业</option>'+
					'<option>全部</option>'+
					'<option>马克思主义哲学</option>'+
					'<option>金融学</option>'+
				 '</select>';
	if(event.srcElement && event.srcElement.tagName=="TH"){
		var major_element = event.srcElement;
		//删除表头专业中原本存在的文本
		major_element.innerText = "";
		//将生成的select标签插入到表头专业中
		major_element.innerHTML = select;
		//专业select事件绑定
		major_select_bind_event();
	}
}
//删除表格，参数：table元素的父元素
function del_table(position){
	var position_children = position.children;
	for (var i = position_children.length-1; i >= 0; i--) {
		position.removeChild(position_children[i]);
	}
}
//表头中院系select事件的绑定
//应注意，每次再点击表头院系之后都应该绑定该事件
function college_select_bind_event(){
	var college_select = get_college_select_element();
	college_select.onchange = college_select_onchange;
}
//院系select选中后的发生事情
function college_select_onchange(){
	//得到当前选中的院系
	var college_select_element = get_college_select_element();
	var index = college_select_element.selectedIndex;
	var college = college_select_element.options[index].value;
	//将原本的表格删除
	del_table(get_content_element());

	
	//根据选择的院系，生成新的表格并插入到content中
	build_table_by_college(college);
	//将得到的college文本插入到college节点中
	var college_element = get_college_element();
	college_element.innerText = college;	
	
}
//根据选择的院系重新生成新的表格插入到content中
function build_table_by_college(college){
	var content = get_content_element();
	var inner = '<table>'+
				'<tr>'+
					'<th>年份</th>'+
					'<th id="college">院系</th>'+
					'<th id="major">专业</th>'+
					'<th>专业代码</th>'+
					'<th>研究方向</th>'+
					'<th>考试范围</th>'+
					'<th>跨专业</th>'+
					'<th>学制</th>'+
					'<th>学术类型</th>'+
				'</tr>';
 	if(college == "全部"){
 		for (var i = 0; i < obj.length; i++) {
			inner += '<tr>'+
      		'<td>'+obj[i].maj_year+'</td>'+
        	'<td>'+obj[i].maj_college_name+'</td>'+
        	'<td>'+obj[i].maj_name+'</td>'+
        	'<td>'+obj[i].maj_code+'</td>'+
        	'<td><a href="#" name="research_direction">详细</a></td>'+
        	'<td><a href="#" name="exam_scope">详细</a></td>';
        	if(obj[i].maj_transdisciplinary == "true"){
        		inner += '<td>支持</td>';
        	}else {
        		inner += '<td>不支持</td>';
        	}
        	inner += 
        			'<td>'+obj[i].maj_system+'</td>'+
        			'<td>'+obj[i].maj_acdemic+'</td>'+
      				'</tr>';
		}
 	}else {
 		for (var i = 0; i < obj.length; i++) {
			if(college == obj[i].maj_college_name){
				inner += '<tr>'+
      			'<td>'+obj[i].maj_year+'</td>'+
        		'<td>'+obj[i].maj_college_name+'</td>'+
        		'<td>'+obj[i].maj_name+'</td>'+
        		'<td>'+obj[i].maj_code+'</td>'+
        		'<td><a href="#" name="research_direction">详细</a></td>'+
        		'<td><a href="#" name="exam_scope">详细</a></td>';
        		if(obj[i].maj_transdisciplinary == "true"){
        			inner += '<td>支持</td>';
        		}else {
        			inner += '<td>不支持</td>';
        		}
        		inner += 
        				'<td>'+obj[i].maj_system+'</td>'+
        				'<td>'+obj[i].maj_acdemic+'</td>'+
      					'</tr>';
			}
		}	
 	}
		    inner += '</table>';
		    content.innerHTML = inner;
		    //给表头中的院校和专业绑定事件
		    th_college_major_bind_event();
		    //给表格绑定事件
		    table_bind_event();
		    //给专业目录绑定事件
		    research_direction_bind_event();
		    //给考试范围绑定事件
		    exam_scope_bind_event();
}
//表头中专业select事件的绑定
function major_select_bind_event(){
	var major_select = get_major_select_element();
	major_select.onchange = major_select_onchange;
}
//专业select选中后发生的事情
function major_select_onchange(){
	//得到当前选中的专业
	var major_select_element = get_major_select_element();
	var index = major_select_element.selectedIndex;
	var major = major_select_element.options[index].value;
	//将原本的表格删除
	del_table(get_content_element());
	
	//根据选择的专业，生成新的表格并插入到content中
	build_table_by_major(major);
	//将得到的college文本插入到college节点中
	var major_element = get_major_element();
	major_element.innerText = major;	
}
//根据选择的专业，生成新的表格并插入到content中
function build_table_by_major(major){
	var content = get_content_element();
	var inner = '<table>'+
				'<tr>'+
					'<th>年份</th>'+
					'<th id="college">院系</th>'+
					'<th id="major">专业</th>'+
					'<th>专业代码</th>'+
					'<th>研究方向</th>'+
					'<th>考试范围</th>'+
					'<th>跨专业</th>'+
					'<th>学制</th>'+
					'<th>学术类型</th>'+
				'</tr>';
 	if(major == "全部"){
 		for (var i = 0; i < obj.length; i++) {
			inner += '<tr>'+
      		'<td>'+obj[i].maj_year+'</td>'+
        	'<td>'+obj[i].maj_college_name+'</td>'+
        	'<td>'+obj[i].maj_name+'</td>'+
        	'<td>'+obj[i].maj_code+'</td>'+
        	'<td><a href="#" name="research_direction">详细</a></td>'+
        	'<td><a href="#" name="exam_scope">详细</a></td>';
        	if(obj[i].maj_transdisciplinary == "true"){
        		inner += '<td>支持</td>';
        	}else {
        		inner += '<td>不支持</td>';
        	}
        	inner += 
        			'<td>'+obj[i].maj_system+'</td>'+
        			'<td>'+obj[i].maj_acdemic+'</td>'+
      				'</tr>';
		}
 	}else {
 		for (var i = 0; i < obj.length; i++) {
			if(major == obj[i].maj_name){
				inner += '<tr>'+
      			'<td>'+obj[i].maj_year+'</td>'+
        		'<td>'+obj[i].maj_college_name+'</td>'+
        		'<td>'+obj[i].maj_name+'</td>'+
        		'<td>'+obj[i].maj_code+'</td>'+
        		'<td><a href="#" name="research_direction">详细</a></td>'+
        		'<td><a href="#" name="exam_scope">详细</a></td>';
        		if(obj[i].maj_transdisciplinary == "true"){
        			inner += '<td>支持</td>';
        		}else {
        			inner += '<td>不支持</td>';
        		}
        		inner += 
        				'<td>'+obj[i].maj_system+'</td>'+
        				'<td>'+obj[i].maj_acdemic+'</td>'+
      					'</tr>';
			}
		}	
 	}
		    inner += '</table>';
		    content.innerHTML = inner;
		    //给表头中的院校和专业绑定事件
		    th_college_major_bind_event();
		    //给表格绑定事件
		    table_bind_event();
		    //给专业目录绑定事件
		    research_direction_bind_event();
		    //给考试范围绑定事件
		    exam_scope_bind_event();
}
//获取college中的select
function get_college_select_element(){
	return document.getElementById("college").firstChild;
}
//获取major中的select
function get_major_select_element(){
	return document.getElementById("major").firstChild;
}

//////////////////////////table有关函数结束//////////////////////////////////////
////////////////////////sidebar有关函数开始//////////////////////////////////////
//获得所有的sidebar
function get_sidebar() {
	return document.getElementsByName("sidebar");
}
//sidebar事件绑定的函数
function sidebar_bind_event(){
	var sidebar = get_sidebar();
	for (var i = 0; i < sidebar.length; i++) {
		sidebar[i].onmouseover = sidebar_onmouseover;
		sidebar[i].onmouseout = sidebar_onmouseout;
		sidebar[i].onclick = sidebar_onclick_enrollment;
	}
}
//sidebar鼠标悬浮事件
function sidebar_onmouseover() {
	if(event.srcElement && event.srcElement.tagName=="IMG"){
		var one_of_sidebar = event.srcElement;
			one_of_sidebar.style.cursor = 'pointer';
			one_of_sidebar.style.transform = 'scale(0.9)';
	}
}
//sidebar鼠标悬浮离开事件
function sidebar_onmouseout() {
	if(event.srcElement && event.srcElement.tagName=="IMG"){
		var one_of_sidebar = event.srcElement;
			one_of_sidebar.style.transform = 'scale(0.8)';	
	}
}
//设置sidebar招生简章图片为选中后的效果图，并将其背景颜色改为白色，用来标识与其他的sidebar的不同
function set_sidebar_enrollment(){
	var sidebar_enrollment_element = get_sidebar_enrollment_element();
	sidebar_enrollment_element.src = "img/sidebar1-1.jpg";
	sidebar_enrollment_element.style.backgroundColor  = 'white';
}	
//设置sidebar专业目录图片为选中后的效果图，并将其背颜色改为白色，用来表示与其他的sidebar的不同
function set_sidebar_professional_catalogue() {
	var sidebar_professional_catalogue_element = get_sidebar_professional_catalogue_element();
	sidebar_professional_catalogue_element.src = "img/sidebar2-2.jpg";
	sidebar_professional_catalogue_element.style.backgroundColor  = 'white';
}
//设置sidebar分数线图片为选中后的效果图，并将其背颜色改为白色，用来表示与其他的sidebar的不同
function set_sidebar_score() {
	var sidebar_score_element = get_sidebar_score_element();
	sidebar_score_element.src = "img/sidebar3-3.jpg";
	sidebar_score_element.style.backgroundColor  = 'white';
}
//设置sidebar报录情况图片为选中后的效果图，并将其背颜色改为白色，用来表示与其他的sidebar的不同
function set_sidebar_admission_situation() {
	var sidebar_admission_situation_element = get_sidebar_admission_situation_element();
	sidebar_admission_situation_element.src = "img/sidebar4-4.jpg";
	sidebar_admission_situation_element.style.backgroundColor  = 'white';
}
//得到sidebar中的报录情况
function get_sidebar_admission_situation_element() {
	return document.getElementById("sidebar4");
}
//得到sidebar中的分数线元素
function get_sidebar_score_element() {
	return document.getElementById("sidebar3");
}
//得到sidebar中的专业目录元素
function get_sidebar_professional_catalogue_element() {
	return document.getElementById("sidebar2");
}
//得到sidebar中的招生简章元素
function get_sidebar_enrollment_element() {
	return document.getElementById("sidebar1");
}
//sidebar点击事件
function sidebar_onclick_enrollment() {
	//获取所有所有的sidebar
	//把原本背景颜色为白色的sidebar改为背景颜色为红色，得到其id，通过if else联级来将其图片设置为未点击之前的状态
	var sidebar = get_sidebar();
	for (var i = 0; i < sidebar.length; i++) {
		if(sidebar[i].style.backgroundColor == "white"){
			//把原本背景颜色为白色的sidebar改为背景颜色为红色
			sidebar[i].style.backgroundColor = "red";

			if(sidebar[i].id == "sidebar1"){
				sidebar[i].src = "img/sidebar1.jpg";
			}else if(sidebar[i].id == "sidebar2"){
				sidebar[i].src = "img/sidebar2.jpg";
			}else if(sidebar[i].id == "sidebar3"){
				sidebar[i].src = "img/sidebar3.jpg";
			}else if(sidebar[i].id == "sidebar4"){
				sidebar[i].src = "img/sidebar4.jpg";
			}
		}
	}
	
	
	if(event.srcElement && event.srcElement.tagName == "IMG"){
		//获取当前点击的sidebar
		var one_of_sidebar = event.srcElement;
		//通过id发送请求
		if(one_of_sidebar.id == "sidebar1"){
			//获得招生简章并将相关数据插入到页面中
			get_enrollment_and_insert_to_page();
		}else if(one_of_sidebar.id == "sidebar2"){
			//获取专业目录并将相关数据插入到页面中
			get_major_and_insert_to_page();
		}else if(one_of_sidebar.id == "sidebar3"){
			//获取分数线并将相关数据插入到页面中
			get_score_and_insert_to_page();
		}else if(one_of_sidebar.id == "sidebar4"){
			//获取报录情况并将相关数据插入到页面中
			get_enrol_and_insert_to_page();	
		}
	}
}
////////////////////////sidebar有关函数结束//////////////////////////////////////


/////////////////////////向后台发送请求相关函数开始////////////////////////////////////
//向后台发送请求获取报录情况并插入到页面中
function get_enrol_and_insert_to_page(){
	//获得要插入的位置content元素
	var content = get_content_element(); 
	//获得参数：学校名称
	var uni_name = get_index_uni_name_element().innerText;
	//拼接URL
	var URL = "http://39.105.39.215:8080/yanxin/renderdata/renderREList?res_uni_name="+uni_name;
	var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange=function()
	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200){

			var txt = xmlhttp.responseText;
			//全局变量
		    obj = eval ("(" + txt + ")");
		    //删除原本content中有的东西
		    delete_content(content);
		    //生成报录情况
		    var inner = '<table>'+
				'<tr>'+
					'<th>年份</th>'+
					'<th id="college">院系</th>'+
					'<th id="major">专业</th>'+
					'<th>研究方向</th>'+
					'<th>报考人数</th>'+
					'<th>录取人数</th>'+
					'<th>展示图</th>'+
				'</tr>';
				for (var i = 0; i < obj.length; i++) {
		    	inner += '<tr>'+
    					'<td>'+obj[i].res_year+'</td>'+
        				'<td>'+obj[i].res_college_name+'</td>'+
        				'<td>'+obj[i].res_maj_name+'</td>'+
        				'<td>'+obj[i].res_name+'</td>'+
        				'<td>'+obj[i].res_register_num+'</td>'+
        				'<td>'+obj[i].res_enroll_num+'</td>'+
        				'<td><a href="page_three.html'+
        				'?res_year='+obj[i].res_year+
        				'&res_uni_name='+get_index_uni_name_element().innerText+
        				'&res_college_name='+obj[i].res_college_name+
        				'&res_maj_name='+obj[i].res_maj_name+
        				'" target="_blank">展示图</a></td>'+
    				'</tr>';
		    	}
		    inner += '</table>';
		    content.innerHTML = inner;
		    //将sidebar中的报录情况切换为选中状态
		    set_sidebar_admission_situation();
		    //给表头绑定事件
		    th_college_major_bind_event();
		    //给表格绑定事件
		    table_bind_event();
		}
	}
	xmlhttp.open("GET",URL,true);
	xmlhttp.send();
}
//向后台发送请求获取分数线并插入到页面中
function get_score_and_insert_to_page(){
	//获得要插入的位置content元素
	var content = get_content_element(); 
	//获得参数：学校名称
	var uni_name = get_index_uni_name_element().innerText;
	//拼接URL
	var URL = "http://39.105.39.215:8080/yanxin/renderdata/renderScoList?sco_uni_name="+uni_name;
	var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange=function()
	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200){

			var txt = xmlhttp.responseText;
			//全局变量
		    obj = eval ("(" + txt + ")");
		    //删除原本content中有的东西
		    delete_content(content);
		    //生成招生简章
		    var inner = '<table>'+
				'<tr>'+
					'<th>年份</th>'+
					'<th id="college">院系</th>'+
					'<th id="major">专业</th>'+
					'<th>国家线</th>'+
					'<th>复试分数线</th>'+
					'<th>自主线</th>'+
					'<th>政治</th>'+
					'<th>外语</th>'+
					'<th>业务一</th>'+
					'<th>业务二</th>'+
				'</tr>';
				for (var i = 0; i < obj.length; i++) {
		    		inner += '<tr>'+
    					'<td>'+obj[i].sco_year+'</td>'+
        				'<td>'+obj[i].sco_college_name+'</td>'+
        				'<td>'+obj[i].sco_maj_name+'</td>'+
        				'<td>'+obj[i].sco_country_line+'</td>'+
        				'<td>'+obj[i].sco_reexamine_line+'</td>'+
        				'<td>'+obj[i].sco_self_line+'</td>'+
        				'<td>'+obj[i].sco_subject1+'</td>'+
        				'<td>'+obj[i].sco_subject2+'</td>'+
        				'<td>'+obj[i].sco_subject3+'</td>'+
        				'<td>'+obj[i].sco_subject4+'</td>'+
    				'</tr>';
		    	}
		    inner += '</table>';
		    content.innerHTML = inner;
		    //将sidebar中的分数线切换为选中状态
		    set_sidebar_score();
		    //给表头绑定事件
		    th_college_major_bind_event();
		    //给表格绑定事件
		    table_bind_event();
		}
	}
	xmlhttp.open("GET",URL,true);
	xmlhttp.send();
}
//向后台发送请求获取招生简章并插入到页面中
function get_enrollment_and_insert_to_page(){
	//获得要插入的位置content元素
	var content = get_content_element(); 
	//获得参数：学校名称
	var uni_name = get_index_uni_name_element().innerText;
	//拼接URL
	var URL = "http://39.105.39.215:8080/yanxin/renderdata/renderRecListbyUniname?rec_uni_name="+uni_name;
	var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange=function()
	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200){

			var txt = xmlhttp.responseText;

			//全局变量
		    var obj = eval ("(" + txt + ")");

		    //删除原本content中有的东西
		    delete_content(content);
		     
		    //生成招生简章
		    var inner = '<h2>'+obj[0].rec_year+'年招生简章</h2>'+
						'<div class="line"></div>'+ 
						'<div class="text">'+obj[0].rec_content+'</div>';

		    content.innerHTML = inner;
		    //将sidebar中的招生简章切换为选中状态
		    set_sidebar_enrollment();
		}
	}
	xmlhttp.open("GET",URL,true);
	xmlhttp.send();
}
//通过发送请求获取专业目录将其展示到content中
function get_major_and_insert_to_page(){
	//得到插入位置
	var content = get_content_element();
	//得到学校名称
	var uni_name = get_index_uni_name_element().innerText;
	//拼接URL
	var URL = "http://39.105.39.215:8080/yanxin/renderdata/renderMajListbyUniname?maj_uni_name="+uni_name;
	var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange=function()
	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200){

			var txt = xmlhttp.responseText;

			//全局变量
		    obj = eval ("(" + txt + ")");
		    var inner = '<table>'+
				'<tr>'+
					'<th>年份</th>'+
					'<th id="college">院系</th>'+
					'<th id="major">专业</th>'+
					'<th>专业代码</th>'+
					'<th>研究方向</th>'+
					'<th>考试范围</th>'+
					'<th>跨专业</th>'+
					'<th>学制</th>'+
					'<th>学术类型</th>'+
				'</tr>';
      				
		    for (var i = 0; i < obj.length; i++) {
		    	inner += '<tr>'+
      					'<td>'+obj[i].maj_year+'</td>'+
        				'<td>'+obj[i].maj_college_name+'</td>'+
        				'<td>'+obj[i].maj_name+'</td>'+
        				'<td>'+obj[i].maj_code+'</td>'+
        				'<td><a href="#" name="research_direction">详细</a></td>'+
        				'<td><a href="#" name="exam_scope">详细</a></td>';
        				if(obj[i].maj_transdisciplinary == "true"){
        					inner += '<td>支持</td>';
        				}else {
        					inner += '<td>不支持</td>';
        				}
        				inner += 
        						'<td>'+obj[i].maj_system+'</td>'+
        						'<td>'+obj[i].maj_acdemic+'</td>'+
      							'</tr>';
		    }
		    inner += '</table>';
		    content.innerHTML = inner;
		    
		    //将sidebar中的专业目录切换为选中状态
		    set_sidebar_professional_catalogue();
		    //给表头绑定事件
		    th_college_major_bind_event();
		    //给表格绑定事件
		    table_bind_event();
		    //给研究方向绑定事件
		    research_direction_bind_event();
		    //给考试范围绑定事件
		    exam_scope_bind_event();
		}
	}
	xmlhttp.open("GET",URL,true);
	xmlhttp.send();
}
/////////////////////////向后台发送请求相关函数结束////////////////////////////////////
