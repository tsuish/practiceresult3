window.onload = function() {
	
	sidebar_init();
}

//初始化侧边栏的高度	
function sidebar_init(){
	// 获得屏幕的高度
	// 获得侧边栏控件
	// 设置侧边栏控件的高度
	var height = window.screen.height;
	var sidebar = document.getElementById("sidebar");
	sidebar.style.top = height*0.3+'px';
}