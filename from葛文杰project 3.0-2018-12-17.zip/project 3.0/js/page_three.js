window.onload = function () {
	drawing_pie_chart();
	drawing_line_chart();
	get_paramaters_from_page_two();
}
/*
函数编号：6
参数：学校名称、学院名称、专业名称
功能：向后台发送请求获取绘制折线图所需要的参数，并调用绘制折线图函数
*/
function get_line_need_paramaters_and_drawing_line_chart(res_uni_name,res_college_name,res_maj_name){
	//URL
	var URL = 'http://39.105.39.215:8080/yanxin/renderdata/renderREList_Detail'+
	'?res_uni_name='+res_uni_name+
	'&res_college_name='+res_college_name+
	'&res_maj_name='+res_maj_name;
	var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange=function()
	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200){
			var txt = xmlhttp.responseText;
			//全局变量
		    obj = eval ("(" + txt + ")");
		    var year = [0,0,0,0,0];
		    var luqu = [0,0,0,0,0];
		    var baoming = [0,0,0,0,0];

		    for (var i = 0; i < obj.length; i++) {
		    	year[i] = obj[i].res_year;
		    	luqu[i] = obj[i].res_enroll_num;
		    	baoming[i] = obj[i].res_register_num;
		    }
		    //生成折线图
		    drawing_line_chart(year,luqu,baoming);
		}
	}
	xmlhttp.open("GET",URL,true);
	xmlhttp.send(); 
}
/*
函数编号：5
参数：年份(数组)、录取人数(数组)、报名人数(数组)
功能：根据参数生成折线统计图
*/
function drawing_line_chart(year,luqu,baoming){
	if(year == null){
		var year = [0,0,0,0,0];
		var luqu = [0,0,0,0,0];
		var baoming = [0,0,0,0,0];
	}
        echarts.init(document.getElementById('line_chart')).setOption(
        {
    title: {
        text: '趋势图'
    },
    tooltip: {
        trigger: 'axis'
    },
    legend: {
        data:['录取人数','报名人数']
    },
    grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },
    toolbox: {
        feature: {
            saveAsImage: {}
        }
    },
    xAxis: {
        type: 'category',
        boundaryGap: false,
        data: [year[4],year[3],year[2],year[1],year[0]]
    },
    yAxis: {
        type: 'value'
    },
    series: [
        {
            name:'录取人数',
            type:'line',
            stack: '总量',
            data:[luqu[4], luqu[3], luqu[2], luqu[1], luqu[0]]
        },
        {
            name:'报名人数',
            type:'line',
            stack: '总量',
            data:[baoming[4], baoming[3], baoming[2], baoming[1], baoming[0]]
        },
        
    ]
}

);
}
/*
函数编号：4
参数：年份、学校名称、学院名称、专业名称
功能：向后台发送请求获取绘制饼状图所需要的参数，并调用绘制饼状图函数
*/
function get_pei_need_paramaters_and_drawing_pie_chart(res_year,res_uni_name,res_college_name,res_maj_name){
	//URL
	var URL = 'http://39.105.39.215:8080/yanxin/renderdata/renderREList_Detail'+
	'?res_year='+res_year+
	'&res_uni_name='+res_uni_name+
	'&res_college_name='+res_college_name+
	'&res_maj_name='+res_maj_name;
	var xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange=function()
	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200){
			var txt = xmlhttp.responseText;
			//全局变量
		    obj = eval ("(" + txt + ")");
		    var luqu = obj[0].res_enroll_num;
		    var weiluqu = obj[0].res_register_num - obj[0].res_enroll_num;
		    //生成饼状图
		    drawing_pie_chart(luqu,weiluqu);
		}
	}
	xmlhttp.open("GET",URL,true);
	xmlhttp.send(); 
}
/*
函数编号：3
参数：录取人数、未录取人数
功能：根据参数绘制饼状图
*/
function drawing_pie_chart(luqu,weiluqu){
	if(luqu == null){
		luqu = 50;
    	weiluqu = 50;
	}	
        // 绘制饼状图
        echarts.init(document.getElementById('pie_chart')).setOption({
            series: {
                type: 'pie',
                data: [
                    {name: '未录取人数：'+weiluqu, value: weiluqu},
                    {name: '录取人数：'+luqu, value: luqu}
                ]
            }
        });
}
/*
函数编号：2
功能：根据年份、学院名称、专业名称三个参数设置页面中饼状图上面的文字提示
*/
function set_pie_p(year,college_name,maj_name){
	//得到p标签元素
	var p = document.getElementById("p");
	//拼接要插入的文字内容
	var text = year+'年'+college_name+maj_name+'录取人数与未录取人数所占比例'
	//将文字内容插入到页面文本中
	p.innerText = text;
}
/*
函数编号：1
功能：获取从第二个页面中传过来的参数,年份、学校名称、学院名称、专业名称
*/
function get_paramaters_from_page_two() {
	var parameters = location.search;
  	if ( parameters.indexOf( "?" ) != -1 ) {
    	var parameter = parameters.substr( 1 ); //substr()方法返回从参数值开始到结束的字符串；
    	var strs = parameter.split( "&");
    	//得到年份
    	var year = strs[0].split("=")[1];
    	//得到学校名称
    	var uni_name = decodeURI(strs[1].split("=")[1]);
    	//得到学院名称
    	var college_name = decodeURI(strs[2].split("=")[1]);
    	//得到专业名称
    	var maj_name = decodeURI(strs[3].split("=")[1]);
    	//生成饼状图的文字提示内容
    	set_pie_p(year,college_name,maj_name);
    	//生成饼状图
    	get_pei_need_paramaters_and_drawing_pie_chart(year,uni_name,college_name,maj_name);
    	//生成折线图
    	get_line_need_paramaters_and_drawing_line_chart(uni_name,college_name,maj_name);
  	}
}


