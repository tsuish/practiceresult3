import requests
from lxml import etree
from YanXin.DAO.DAO_university import DAO_university


class DATA_university:
    # 获取院校信息，不包括院校代码uni_code，返回list，所有院校信息，包括recruit_link 招生简章主链接，从研招网
    def university(self):
        dao = DAO_university()
        urls = ['https://yz.chsi.com.cn/sch/?start={}'.format(str(i)) for i in range(0, 841, 20)]
        for page, url in enumerate(urls):
            headers = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36"}
            response = requests.get(url, headers=headers)
            response_json_str = response.content.decode()
            response_html = etree.HTML(response_json_str)   # type(response_html)   <class 'lxml.etree._Element'>
            div_arr = response_html.xpath("//tbody/tr")
            print("第", page+1, "页")
            for i, div_one in enumerate(div_arr):
                uni_id = page*20+i+1
                uni_name = div_one.xpath("./td[1]/a/text()")[0].split()[0]
                uni_location = div_one.xpath("./td[2]/text()")[0]
                uni_subjection = div_one.xpath("./td[3]/text()")[0]
                uni_characteristics = div_one.xpath("./td[4]/span/text()")
                uni_characteristic = ''
                for f in uni_characteristics:
                    uni_characteristic = uni_characteristic+f+' '
                uni_graduate_schools = div_one.xpath("./td[5]/i/text()") # graduate_schools 研究生院
                if len(uni_graduate_schools) == 1:
                    uni_graduate_school = True
                else:
                    uni_graduate_school = False
                uni_self_lines = div_one.xpath("./td[6]/i/text()")
                if len(uni_self_lines) == 1:
                    uni_self_line = True
                else:
                    uni_self_line = False
                recruit_link = 'https://yz.chsi.com.cn' + div_one.xpath("./td[@class='text_center']/a/@href")[0]  # recruit_link 招生简章主链接
                print(uni_id, '\t', uni_name, '\t', uni_location, '\t', uni_subjection, '\t', uni_characteristic, '\t', uni_graduate_school, '\t', uni_self_line, '\t', recruit_link)
                # dao.add(uni_id, 0, uni_name, uni_location, uni_subjection, uni_characteristic, uni_graduate_school, uni_self_line)


if __name__ == '__main__':

    # 插入university数据（uni_code待定）
    # data = DATA()
    # data.university()
    print("1、爬取所有院校 数据")
    print("2、清空数据库(待定)")
    print("3、输出所有数据")
    res = int(input())
    if res == 1:
        university = DATA_university()
        university.university()
    elif res == 2:
        pass
        # dao = DAO_university()
        # dao.truncate()
    elif res == 3:
        dao = DAO_university()
        dao.sel_all()
