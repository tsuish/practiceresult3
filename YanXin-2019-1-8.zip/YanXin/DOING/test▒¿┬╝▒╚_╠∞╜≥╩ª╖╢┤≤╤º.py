import requests
import socket
from lxml import etree
from YanXin.DOING.dao_报录比 import DAO_报录比
class test_报录比_天津师范大学:
    # 天津师范大学，无录取人数数据
    #
    def 天津师范大学(self, url, res_year, res_uni_name, startnum, endnum, college_i, maj_i, res_i, register_i, res_recommend_i):
        socket.setdefaulttimeout(5000)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36"}
        string = requests.get(url, headers=headers, timeout=5000).content.decode()
        element = etree.HTML(string)
        ones = element.xpath('//table//tr')
        i = 1
        res_enroll_num = -1
        dao = DAO_报录比()
        college_i = str(college_i)
        maj_i = str(maj_i)
        res_i = str(res_i)
        register_i = str(register_i)
        res_recommend_i = str(res_recommend_i)
        for one in ones:
            if i >= startnum and i <= endnum:
                res_college_name = str(one.xpath('./td['+college_i+']/text()')[0])
                res_maj_name = str(one.xpath('./td['+maj_i+']/text()')[0]).strip("★")
                if res_i == "0":
                    res_name = ""
                else:
                    res_name = str(one.xpath('./td['+res_i+']/text()')[0])
                res_register_num = int(one.xpath('./td['+register_i+']/text()')[0])
                res_recommend_num = int(one.xpath('./td['+res_recommend_i+']/text()')[0])
                if res_register_num == -1 and res_recommend_num == -1:
                    print(i, res_maj_name, '没有报录比数据')
                else:
                    print(i, res_year, res_uni_name, res_college_name, res_maj_name, res_name, res_register_num, res_enroll_num, res_recommend_num)
                    # dao.add_报录比_name_way(res_year, res_register_num, res_enroll_num, res_recommend_num, res_uni_name, res_college_name, res_maj_name, res_name, "")
            i += 1
    def 大学_测(self, url, res_year, res_uni_name, startnum, endnum, college_i, maj_i, register_i, enroll_i, res_recommend_i):
        socket.setdefaulttimeout(5000)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36"}
        string = requests.get(url, headers=headers, timeout=5000).content.decode()
        element = etree.HTML(string)
        ones = element.xpath('//table//tr')
        i = 1
        res_recommend_num = -1
        college_i = str(college_i)
        maj_i = str(maj_i)
        register_i = str(register_i)
        enroll_i = str(enroll_i)
        dao = DAO_报录比()
        for one in ones:
            print(i, one.xpath('./td['+college_i+']/text()'), one.xpath('./td['+maj_i+']/text()'), one.xpath('./td['+register_i+']/text()'), one.xpath('./td['+enroll_i+']/text()'))
            i += 1
