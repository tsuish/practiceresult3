import requests
import socket
from lxml import etree
from YanXin.DOING.dao_报录比 import DAO_报录比
class test_报录比_浙江大学:
    def 浙江大学(self, url, res_year, res_uni_name, startnum, endnum):
        socket.setdefaulttimeout(5000)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36"}
        string = requests.get(url, headers=headers, timeout=5000).content.decode()
        element = etree.HTML(string)
        ones = element.xpath('//table//tr')
        i = 1
        res_recommend_num = -1
        dao = DAO_报录比()
        for one in ones:
            # print(i, one.xpath('./td[2]/text()'), one.xpath('./td[4]/text()'), one.xpath('./td[5]/text()'), one.xpath('./td[6]/text()'))
            if i >= startnum and i <= endnum:
                res_college_name = str(one.xpath('./td[2]/text()')[0])
                res_maj_name = str(one.xpath('./td[4]/text()')[0]).strip('★')
                res_register_num = int(one.xpath('./td[5]/text()')[0])
                res_enroll_num = int(one.xpath('./td[6]/text()')[0])
                if res_register_num == 0 and res_enroll_num == 0:
                    print(i, res_maj_name, '没有报录比数据')
                else:
                    print(i, res_year, res_uni_name, res_college_name, res_maj_name, res_register_num, res_enroll_num, res_recommend_num)
                    # dao.add_报录比(res_year, res_register_num, res_enroll_num, res_recommend_num, res_uni_name, res_college_name, res_maj_name)
            i += 1
    def 浙江大学_测(self, url, res_year, res_uni_name, startnum, endnum):
        socket.setdefaulttimeout(5000)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36"}
        string = requests.get(url, headers=headers, timeout=5000).content.decode()
        element = etree.HTML(string)
        ones = element.xpath('//table//tr')
        i = 1
        res_recommend_num = -1
        dao = DAO_报录比()
        for one in ones:
            print(i, one.xpath('./td[2]/text()'), one.xpath('./td[4]/text()'), one.xpath('./td[5]/text()'), one.xpath('./td[6]/text()'))
            i += 1
