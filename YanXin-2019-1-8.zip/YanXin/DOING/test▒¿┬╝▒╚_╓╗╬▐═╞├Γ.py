import requests
import socket
from lxml import etree
from YanXin.DOING.dao_报录比 import DAO_报录比
class test_报录比_只无推免:
    '''
    中央民族大学2015年数据，需要修改代码为如下：
    res_maj_name = str(one.xpath('./td['+maj_i+']/b/text()')[0]).strip('★')
    '''
    def 大学(self, url, res_year, res_uni_name, startnum, endnum, college_i, maj_i, register_i, enroll_i):
        socket.setdefaulttimeout(5000)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36"}
        string = requests.get(url, headers=headers, timeout=5000).content.decode()
        element = etree.HTML(string)
        ones = element.xpath('//table//tr')
        i = 1
        res_recommend_num = -1
        dao = DAO_报录比()
        college_i = str(college_i)
        maj_i = str(maj_i)
        register_i = str(register_i)
        enroll_i = str(enroll_i)
        for one in ones:
            if i >= startnum and i <= endnum:
                res_college_name = str(one.xpath('./td['+college_i+']/text()')[0])
                res_maj_name = str(one.xpath('./td['+maj_i+']/text()')[0]).strip('★')
                if len(one.xpath('./td['+register_i+']/text()'))==0:
                    res_register_num = -1
                elif one.xpath('./td['+register_i+']/text()')[0] == '\xa0':
                    res_register_num = -1
                else:
                    res_register_num = int(one.xpath('./td['+register_i+']/text()')[0])
                if one.xpath('./td['+enroll_i+']/text()')[0] == '\xa0':
                    res_enroll_num = -1
                else:
                    res_enroll_num = int(one.xpath('./td['+enroll_i+']/text()')[0])
                # if one.xpath('./td['+recommend_i+']/text()')[0] == '\xa0':
                #     res_recommend_num = -1
                # else:
                #     res_recommend_num = int(one.xpath('./td['+recommend_i+']/text()')[0])
                if res_register_num == -1 and res_enroll_num == -1:
                    print(i, res_maj_name, '没有报录比数据')
                else:
                    print(i, res_year, res_uni_name, res_college_name, res_maj_name, res_register_num, res_enroll_num, res_recommend_num)
                    # dao.add_报录比(res_year, res_register_num, res_enroll_num, res_recommend_num, res_uni_name, res_college_name, res_maj_name)
            i += 1
    def 对外经贸大学(self, url, res_year, res_uni_name, startnum, endnum, college_i, maj_i, register_i, enroll_i):
        socket.setdefaulttimeout(5000)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36"}
        string = requests.get(url, headers=headers, timeout=5000).content.decode()
        element = etree.HTML(string)
        ones = element.xpath('//table//tr')
        i = 1
        res_recommend_num = -1
        dao = DAO_报录比()
        college_i = str(college_i)
        maj_i = str(maj_i)
        register_i = str(register_i)
        enroll_i = str(enroll_i)
        for one in ones:
            if i >= startnum and i <= endnum:
                res_college_name = str(one.xpath('./td['+college_i+']/text()')[0]).split("）")[1].strip("\u3000")
                res_maj_name = str(one.xpath('./td['+maj_i+']/text()')[0]).split("）")[1]
                if len(one.xpath('./td['+register_i+']/text()'))==0:
                    res_register_num = -1
                elif one.xpath('./td['+register_i+']/text()')[0] == '\xa0':
                    res_register_num = -1
                else:
                    res_register_num = int(one.xpath('./td['+register_i+']/text()')[0])
                if one.xpath('./td['+enroll_i+']/text()')[0] == '\xa0':
                    res_enroll_num = -1
                else:
                    res_enroll_num = int(one.xpath('./td['+enroll_i+']/text()')[0])
                # if one.xpath('./td['+recommend_i+']/text()')[0] == '\xa0':
                #     res_recommend_num = -1
                # else:
                #     res_recommend_num = int(one.xpath('./td['+recommend_i+']/text()')[0])
                if res_register_num == -1 and res_enroll_num == -1:
                    print(i, res_maj_name, '没有报录比数据')
                else:
                    print(i, res_year, res_uni_name, res_college_name, res_maj_name, res_register_num, res_enroll_num, res_recommend_num)
                    # dao.add_报录比(res_year, res_register_num, res_enroll_num, res_recommend_num, res_uni_name, res_college_name, res_maj_name)
            i += 1
    def 大学_测(self, url, res_year, res_uni_name, startnum, endnum, college_i, maj_i, register_i, enroll_i):
        socket.setdefaulttimeout(5000)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36"}
        string = requests.get(url, headers=headers, timeout=5000).content.decode()
        element = etree.HTML(string)
        ones = element.xpath('//table//tr')
        i = 1
        res_recommend_num = -1
        college_i = str(college_i)
        maj_i = str(maj_i)
        register_i = str(register_i)
        enroll_i = str(enroll_i)
        dao = DAO_报录比()
        for one in ones:
            print(i, one.xpath('./td['+college_i+']/text()'), one.xpath('./td['+maj_i+']/text()'), one.xpath('./td['+register_i+']/text()'), one.xpath('./td['+enroll_i+']/text()'))
            i += 1
