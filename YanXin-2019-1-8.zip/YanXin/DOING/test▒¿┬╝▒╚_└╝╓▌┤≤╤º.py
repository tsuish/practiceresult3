import requests
import socket
from lxml import etree
from YanXin.DOING.dao_报录比 import DAO_报录比
'''
readme:

兰州大学 
2014年：
    1.  requests.get(url_2014, headers=headers, timeout=5000).content.decode()
    2.  buff = 1
    3.  res_year = 2014
2015年：
    1.  requests.get(url_2015, headers=headers, timeout=5000).content.decode()
    2.  buff = 0
    3.  res_year = 2015
'''
class test报录比_兰州大学:
    def test报录比_兰州大学(self, url, buff, res_year):
        socket.setdefaulttimeout(5000)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36"}
        string = requests.get(url, headers=headers, timeout=5000).content.decode()
        # print(string)
        element = etree.HTML(string)
        ones = element.xpath('//table[2]//tr')
        dao = DAO_报录比()
        i = 1
        res_uni_name = '兰州大学'
        for one in ones:
            if i > 4:
                res_college_name = str(one.xpath('.//td['+str(buff+1)+']/text()')[0])
                res_maj_name = str(one.xpath('.//td['+str(buff+3)+']/text()')[0])
                res_register_num = int(one.xpath('.//td['+str(buff+5)+']/text()')[0])
                res_enroll_num = int(one.xpath('.//td['+str(buff+8)+']/text()')[0])
                res_recommend_num = int(one.xpath('.//td['+str(buff+6)+']/text()')[0])
                print(i, res_year, res_uni_name, res_college_name, res_maj_name, res_register_num, res_enroll_num, res_recommend_num)
                dao.add_报录比(res_year, res_register_num, res_enroll_num, res_recommend_num, res_uni_name, res_college_name, res_maj_name)
            i += 1
if __name__ == '__main__':
    test = test报录比_兰州大学()
    url_2014 = 'http://kaoyan.eol.cn/tiao_ji/baolubi/201509/t20150901_1310573.shtml'
    url_2015 = 'http://kaoyan.eol.cn/ge_di_kao_yan/gansu/gan_su/201608/t20160809_1438380.shtml'
    print("-"*20+"\n"
                 "1. 输入2014：爬取兰州大学2014年的报录比信息\n"
                 "2. 输入2015：爬取兰州大学2015年的报录比信息"
                 ""+"\n"+"-" * 20)
    choice = int(input())
    if choice == 2014:
        test.test报录比_兰州大学(url_2014, 1, choice)
        print('2014 is ok')
    elif choice == 2015:
        test.test报录比_兰州大学(url_2015, 0, choice)
        print('2015 is ok')
    #
    # test.test报录比_兰州大学(url_2014)