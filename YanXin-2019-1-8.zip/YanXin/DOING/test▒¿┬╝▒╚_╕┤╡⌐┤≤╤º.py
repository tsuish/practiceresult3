import requests
import datetime
import socket
from lxml import etree
from YanXin.DOING.dao_报录比 import DAO_报录比
class test_报录比_复旦大学:
    def 复旦大学2017(self):
        '''
            0:00:14.248004 秒
            1  : url_2017
            2  : res_year
            3  : requests.get(url_2017.......
            4  : if i > 3 and i < 209:
        '''
        url_2017 = 'http://kaoyan.eol.cn/tiao_ji/baolubi/201712/t20171224_1575852.shtml'
        socket.setdefaulttimeout(5000)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36"}
        string = requests.get(url_2017, headers=headers, timeout=5000).content.decode()
        element = etree.HTML(string)
        ones = element.xpath('//table//tr')
        i = 1
        res_year = 2017
        res_uni_name = '复旦大学'
        res_college_name = ''
        dao = DAO_报录比()
        for one in ones:
            # print(i, one.xpath('./td[1]/text()'), one.xpath('./td[2]/text()'))
            if i > 3 and i < 184:
                res_maj_name = str(one.xpath('./td[2]/text()')[0])
                # print(res_maj_name, one.xpath('./td[11]/text()'), one.xpath('./td[12]/text()'), one.xpath('./td[13]/text()'))
                if one.xpath('./td[11]/text()')[0] == '\xa0':
                    res_register_num = -1
                else:
                    res_register_num = int(one.xpath('./td[11]/text()')[0])
                if one.xpath('./td[12]/text()')[0] == '\xa0':
                    res_enroll_num = -1
                else:
                    res_enroll_num = int(one.xpath('./td[12]/text()')[0])
                if one.xpath('./td[13]/text()')[0] == '\xa0':
                    res_recommend_num = -1
                else:
                    res_recommend_num = int(one.xpath('./td[13]/text()')[0])
                print(i, res_year, res_uni_name, res_college_name, res_maj_name, res_register_num, res_enroll_num, res_recommend_num)
                # dao.add_报录比(res_year, res_register_num, res_enroll_num, res_recommend_num, res_uni_name, res_college_name, res_maj_name)
            i += 1
    def 复旦大学2016_学(self):
        '''
            0:00:14.248004 秒
            1  : url_2017
            2  : res_year
            3  : requests.get(url_2017.......
            4  : if i > 3 and i < 209:
        '''
        url_2016_学 = 'http://kaoyan.eol.cn/tiao_ji/baolubi/201712/t20171224_1575852.shtml'
        socket.setdefaulttimeout(5000)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36"}
        string = requests.get(url_2016_学, headers=headers, timeout=5000).content.decode()
        element = etree.HTML(string)
        ones = element.xpath('//table//tr')
        i = 1
        res_year = 2016
        res_uni_name = '复旦大学'
        res_college_name = ''
        dao = DAO_报录比()
        for one in ones:
            # print(i, one.xpath('./td[1]/text()'), one.xpath('./td[2]/text()'))
            if i > 3 and i < 184:
                res_maj_name = str(one.xpath('./td[2]/text()')[0])
                # print(res_maj_name, one.xpath('./td[11]/text()'), one.xpath('./td[12]/text()'), one.xpath('./td[13]/text()'))
                if one.xpath('./td[7]/text()')[0] == '\xa0':
                    res_register_num = -1
                else:
                    res_register_num = int(one.xpath('./td[7]/text()')[0])
                if one.xpath('./td[8]/text()')[0] == '\xa0':
                    res_enroll_num = -1
                else:
                    res_enroll_num = int(one.xpath('./td[8]/text()')[0])
                if one.xpath('./td[9]/text()')[0] == '\xa0':
                    res_recommend_num = -1
                else:
                    res_recommend_num = int(one.xpath('./td[9]/text()')[0])
                print(i, res_year, res_uni_name, res_college_name, res_maj_name, res_register_num, res_enroll_num, res_recommend_num)
                # dao.add_报录比(res_year, res_register_num, res_enroll_num, res_recommend_num, res_uni_name, res_college_name, res_maj_name)
            i += 1
    def 复旦大学2015_学(self):
        '''
            0:00:14.248004 秒
            1  : url_2017
            2  : res_year
            3  : requests.get(url_2017.......
            4  : if i > 3 and i < 209:
        '''
        url_2015_学 = 'http://kaoyan.eol.cn/tiao_ji/baolubi/201712/t20171224_1575852.shtml'
        socket.setdefaulttimeout(5000)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36"}
        string = requests.get(url_2015_学, headers=headers, timeout=5000).content.decode()
        element = etree.HTML(string)
        ones = element.xpath('//table//tr')
        i = 1
        res_year = 2015
        res_uni_name = '复旦大学'
        res_college_name = ''
        dao = DAO_报录比()
        for one in ones:
            # print(i, one.xpath('./td[1]/text()'), one.xpath('./td[2]/text()'))
            if i > 3 and i < 184:
                res_maj_name = str(one.xpath('./td[2]/text()')[0])
                # print(res_maj_name, one.xpath('./td[11]/text()'), one.xpath('./td[12]/text()'), one.xpath('./td[13]/text()'))
                if one.xpath('./td[3]/text()')[0] == '\xa0':
                    res_register_num = -1
                else:
                    res_register_num = int(one.xpath('./td[3]/text()')[0])
                if one.xpath('./td[4]/text()')[0] == '\xa0':
                    res_enroll_num = -1
                else:
                    res_enroll_num = int(one.xpath('./td[4]/text()')[0])
                if one.xpath('./td[5]/text()')[0] == '\xa0':
                    res_recommend_num = -1
                else:
                    res_recommend_num = int(one.xpath('./td[5]/text()')[0])
                print(i, res_year, res_uni_name, res_college_name, res_maj_name, res_register_num, res_enroll_num, res_recommend_num)
                # dao.add_报录比(res_year, res_register_num, res_enroll_num, res_recommend_num, res_uni_name, res_college_name, res_maj_name)
            i += 1
    def 复旦大学2014_学(self):
        '''
            0:00:14.248004 秒
            1  : url_2017
            2  : res_year
            3  : requests.get(url_2017.......
            4  : if i > 3 and i < 209:
        '''
        url_2014_学 = 'http://kaoyan.eol.cn/tiao_ji/baolubi/201509/t20150901_1310575.shtml'
        socket.setdefaulttimeout(5000)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36"}
        string = requests.get(url_2014_学, headers=headers, timeout=5000).content.decode()
        element = etree.HTML(string)
        ones = element.xpath('//table//tr')
        i = 1
        res_year = 2014
        res_uni_name = '复旦大学'
        res_college_name = ''
        dao = DAO_报录比()
        for one in ones:
            # print(i, one.xpath('./td[1]/text()'), one.xpath('./td[2]/text()'))
            if i > 5 and i < 191:
                res_maj_name = str(one.xpath('./td[2]/text()')[0])
                # print(res_maj_name, one.xpath('./td[11]/text()'), one.xpath('./td[12]/text()'), one.xpath('./td[13]/text()'))
                if one.xpath('./td[11]/text()')[0] == '\xa0':
                    res_register_num = -1
                else:
                    res_register_num = int(one.xpath('./td[11]/text()')[0])
                if one.xpath('./td[12]/text()')[0] == '\xa0':
                    res_enroll_num = -1
                else:
                    res_enroll_num = int(one.xpath('./td[12]/text()')[0])
                if one.xpath('./td[13]/text()')[0] == '\xa0':
                    res_recommend_num = -1
                else:
                    res_recommend_num = int(one.xpath('./td[13]/text()')[0])
                if res_register_num == -1 and res_enroll_num == -1 and res_recommend_num == -1:
                    print(i, res_maj_name, '没有报录比数据')
                else:
                    print(i, res_year, res_uni_name, res_college_name, res_maj_name, res_register_num, res_enroll_num, res_recommend_num)
                    # dao.add_报录比(res_year, res_register_num, res_enroll_num, res_recommend_num, res_uni_name, res_college_name, res_maj_name)
            i += 1
    def 复旦大学2016_专(self):
        '''
            0:00:14.248004 秒
            1  : url_2017
            2  : res_year
            3  : requests.get(url_2017.......
            4  : if i > 3 and i < 209:
        '''
        url_2016_专 = 'http://kaoyan.eol.cn/tiao_ji/baolubi/201707/t20170727_1543940.shtml'
        socket.setdefaulttimeout(5000)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36"}
        string = requests.get(url_2016_专, headers=headers, timeout=5000).content.decode()
        element = etree.HTML(string)
        ones = element.xpath('//table//tr')
        i = 1
        res_year = 2016
        res_uni_name = '复旦大学'
        res_college_name = ''
        dao = DAO_报录比()
        for one in ones:
            # print(i, one.xpath('./td[1]/text()'), one.xpath('./td[2]/text()'))
            if i > 6 and i < 60:
                res_maj_name = str(one.xpath('./td[2]/text()')[0]).split(')')[1]
                # print(res_maj_name, one.xpath('./td[11]/text()'), one.xpath('./td[12]/text()'), one.xpath('./td[13]/text()'))
                if one.xpath('./td[11]/text()')[0] == '\xa0':
                    res_register_num = -1
                else:
                    res_register_num = int(one.xpath('./td[11]/text()')[0])
                if one.xpath('./td[12]/text()')[0] == '\xa0':
                    res_enroll_num = -1
                else:
                    res_enroll_num = int(one.xpath('./td[12]/text()')[0])
                if one.xpath('./td[13]/text()')[0] == '\xa0':
                    res_recommend_num = -1
                else:
                    res_recommend_num = int(one.xpath('./td[13]/text()')[0])
                if res_register_num == -1 and res_enroll_num == -1 and res_recommend_num == -1:
                    print(i, res_maj_name, '没有报录比数据')
                else:
                    print(i, res_year, res_uni_name, res_college_name, res_maj_name, res_register_num, res_enroll_num, res_recommend_num)
                    # dao.add_报录比(res_year, res_register_num, res_enroll_num, res_recommend_num, res_uni_name, res_college_name, res_maj_name)
            i += 1
    def 复旦大学2015_专(self):
        '''
            0:00:14.248004 秒
            1  : url_2017
            2  : res_year
            3  : requests.get(url_2017.......
            4  : if i > 3 and i < 209:
        '''
        url_2015_专 = 'http://kaoyan.eol.cn/tiao_ji/baolubi/201707/t20170727_1543940.shtml'
        socket.setdefaulttimeout(5000)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36"}
        string = requests.get(url_2015_专, headers=headers, timeout=5000).content.decode()
        element = etree.HTML(string)
        ones = element.xpath('//table//tr')
        i = 1
        res_year = 2015
        res_uni_name = '复旦大学'
        res_college_name = ''
        dao = DAO_报录比()
        for one in ones:
            # print(i, one.xpath('./td[1]/text()'), one.xpath('./td[2]/text()'))
            if i > 6 and i < 60:
                res_maj_name = str(one.xpath('./td[2]/text()')[0]).split(')')[1]
                # print(res_maj_name, one.xpath('./td[11]/text()'), one.xpath('./td[12]/text()'), one.xpath('./td[13]/text()'))
                if one.xpath('./td[7]/text()')[0] == '\xa0':
                    res_register_num = -1
                else:
                    res_register_num = int(one.xpath('./td[7]/text()')[0])
                if one.xpath('./td[8]/text()')[0] == '\xa0':
                    res_enroll_num = -1
                else:
                    res_enroll_num = int(one.xpath('./td[8]/text()')[0])
                if one.xpath('./td[9]/text()')[0] == '\xa0':
                    res_recommend_num = -1
                else:
                    res_recommend_num = int(one.xpath('./td[9]/text()')[0])
                if res_register_num == -1 and res_enroll_num == -1 and res_recommend_num == -1:
                    print(i, res_maj_name, '没有报录比数据')
                else:
                    print(i, res_year, res_uni_name, res_college_name, res_maj_name, res_register_num, res_enroll_num, res_recommend_num)
                    # dao.add_报录比(res_year, res_register_num, res_enroll_num, res_recommend_num, res_uni_name, res_college_name, res_maj_name)
            i += 1
    def 复旦大学2014_专(self):
        '''
            0:00:14.248004 秒
            1  : url_2017
            2  : res_year
            3  : requests.get(url_2017.......
            4  : if i > 3 and i < 209:
        '''
        url_2014_专 = 'http://kaoyan.eol.cn/tiao_ji/baolubi/201707/t20170727_1543940.shtml'
        socket.setdefaulttimeout(5000)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36"}
        string = requests.get(url_2014_专, headers=headers, timeout=5000).content.decode()
        element = etree.HTML(string)
        ones = element.xpath('//table//tr')
        i = 1
        res_year = 2014
        res_uni_name = '复旦大学'
        res_college_name = ''
        dao = DAO_报录比()
        for one in ones:
            # print(i, one.xpath('./td[1]/text()'), one.xpath('./td[2]/text()'))
            if i > 6 and i < 60:
                res_maj_name = str(one.xpath('./td[2]/text()')[0]).split(')')[1]
                # print(res_maj_name, one.xpath('./td[11]/text()'), one.xpath('./td[12]/text()'), one.xpath('./td[13]/text()'))
                if one.xpath('./td[3]/text()')[0] == '\xa0':
                    res_register_num = -1
                else:
                    res_register_num = int(one.xpath('./td[3]/text()')[0])
                if one.xpath('./td[4]/text()')[0] == '\xa0':
                    res_enroll_num = -1
                else:
                    res_enroll_num = int(one.xpath('./td[4]/text()')[0])
                if one.xpath('./td[5]/text()')[0] == '\xa0':
                    res_recommend_num = -1
                else:
                    res_recommend_num = int(one.xpath('./td[5]/text()')[0])
                if res_register_num == -1 and res_enroll_num == -1 and res_recommend_num == -1:
                    print(i, res_maj_name, '没有报录比数据')
                else:
                    print(i, res_year, res_uni_name, res_college_name, res_maj_name, res_register_num, res_enroll_num, res_recommend_num)
                    # dao.add_报录比(res_year, res_register_num, res_enroll_num, res_recommend_num, res_uni_name, res_college_name, res_maj_name)
            i += 1
if __name__ == '__main__':
    starttime = datetime.datetime.now()
    test = test_报录比_复旦大学()
    # test.复旦大学2017()
    # test.复旦大学2016_学()
    # test.复旦大学2015_学()
    # test.复旦大学2014_学()

    # test.复旦大学2016_专()
    # test.复旦大学2015_专()
    # test.复旦大学2014_专()
    endtime = datetime.datetime.now()
    processtime = endtime - starttime
    print("开始时间: ", starttime, "   结束时间: ", endtime)
    print("运行时间: ", processtime, "秒")

