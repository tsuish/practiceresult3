import requests
import datetime
import socket
from lxml import etree
from YanXin.DOING.dao_报录比 import DAO_报录比
class test_报录比_南开大学:
    def 南开2018(self):
        url_2018 = 'http://kaoyan.eol.cn/tiao_ji/baolubi/201807/t20180730_1619331.shtml'
        socket.setdefaulttimeout(5000)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36"}
        string = requests.get(url_2018, headers=headers, timeout=5000).content.decode()
        element = etree.HTML(string)
        ones = element.xpath('//table//tr')
        i = 1
        res_year = 2018
        res_uni_name = '南开大学'
        res_recommend_num = -1
        dao = DAO_报录比()
        paras = []
        for one in ones:
            if i > 3 and i < 218:
                res_college_name = str(one.xpath('./td[1]/text()')[0])
                res_maj_name = str(one.xpath('./td[2]/text()')[0])
                res_register_num = int(one.xpath('./td[3]/text()')[0])
                res_enroll_num = int(one.xpath('./td[4]/text()')[0])
                print(i, res_year, res_uni_name, res_college_name, res_maj_name, res_register_num, res_enroll_num, res_recommend_num)
                dao.update_报录比_单行更新(res_year, res_register_num, res_enroll_num, res_recommend_num, res_uni_name, res_college_name, res_maj_name)
                # 多行更新11111   paras.append((res_register_num, res_enroll_num, res_recommend_num, res_year, res_uni_name, res_college_name, res_maj_name))
            i += 1
        #多行更新2222222  dao.update_报录比(paras)
    def 南开2017(self):
        '''
            0:00:14.248004 秒
            1  : url_2017
            2  : res_year
            3  : requests.get(url_2017.......
            4  : if i > 3 and i < 209:
        '''
        url_2017 = 'http://kaoyan.eol.cn/tiao_ji/baolubi/201711/t20171123_1569083.shtml'
        socket.setdefaulttimeout(5000)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36"}
        string = requests.get(url_2017, headers=headers, timeout=5000).content.decode()
        element = etree.HTML(string)
        ones = element.xpath('//table//tr')
        i = 1
        res_year = 2017
        res_uni_name = '南开大学'
        res_recommend_num = -1
        dao = DAO_报录比()
        for one in ones:
            if i > 3 and i < 209:
                res_college_name = str(one.xpath('./td[1]/text()')[0])
                res_maj_name = str(one.xpath('./td[2]/text()')[0])
                res_register_num = int(one.xpath('./td[3]/text()')[0])
                res_enroll_num = int(one.xpath('./td[4]/text()')[0])
                print(i, res_year, res_uni_name, res_college_name, res_maj_name, res_register_num, res_enroll_num, res_recommend_num)
                dao.add_报录比(res_year, res_register_num, res_enroll_num, res_recommend_num, res_uni_name, res_college_name, res_maj_name)
            i += 1
    def 南开2016(self):
        '''
            0:00:14.248004 秒
            1  : url_2017
            2  : res_year
            3  : requests.get(url_2017.......
            4  : if i > 3 and i < 209:
        '''
        url_2016 = 'http://kaoyan.eol.cn/tiao_ji/baolubi/201707/t20170727_1543929.shtml'
        socket.setdefaulttimeout(5000)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36"}
        string = requests.get(url_2016, headers=headers, timeout=5000).content.decode()
        element = etree.HTML(string)
        ones = element.xpath('//table//tr')
        i = 1
        res_year = 2016
        res_uni_name = '南开大学'
        res_recommend_num = -1
        dao = DAO_报录比()
        for one in ones:
            if i > 5 and i < 217:
                res_college_name = str(one.xpath('./td[1]/text()')[0])
                res_maj_name = str(one.xpath('./td[2]/text()')[0])
                res_register_num = int(one.xpath('./td[3]/text()')[0])
                res_enroll_num = int(one.xpath('./td[4]/text()')[0])
                print(i, res_year, res_uni_name, res_college_name, res_maj_name, res_register_num, res_enroll_num, res_recommend_num)
                dao.add_报录比(res_year, res_register_num, res_enroll_num, res_recommend_num, res_uni_name, res_college_name, res_maj_name)
            i += 1
    def 南开2015(self):
        '''
            0:00:14.248004 秒
            1  : url_2017
            2  : res_year
            3  : requests.get(url_2017.......
            4  : if i > 3 and i < 209:
        '''
        url_2015 = 'http://kaoyan.eol.cn/ge_di_kao_yan/tianjin/tian_jin/201608/t20160803_1436769.shtml'
        socket.setdefaulttimeout(5000)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36"}
        string = requests.get(url_2015, headers=headers, timeout=5000).content.decode()
        element = etree.HTML(string)
        ones = element.xpath('//table//tr')
        i = 1
        res_year = 2015
        res_uni_name = '南开大学'
        res_recommend_num = -1
        dao = DAO_报录比()
        for one in ones:
            # print(i, one.xpath('./td[1]/text()'), one.xpath('./td[2]/text()'))
            if i > 3 and i < 234:
                res_college_name = str(one.xpath('./td[1]/text()')[0]).strip('★')
                res_maj_name = str(one.xpath('./td[2]/text()')[0]).strip('★')
                res_register_num = int(one.xpath('./td[3]/text()')[0])
                res_enroll_num = int(one.xpath('./td[4]/text()')[0])
                print(i, res_year, res_uni_name, res_college_name, res_maj_name, res_register_num, res_enroll_num, res_recommend_num)
                dao.add_报录比(res_year, res_register_num, res_enroll_num, res_recommend_num, res_uni_name, res_college_name, res_maj_name)
            i += 1
    def 南开2014(self):
        '''
            0:00:14.248004 秒
            1  : url_2017
            2  : res_year
            3  : requests.get(url_2017.......
            4  : if i > 3 and i < 209:
        '''
        url_2014 = 'http://kaoyan.eol.cn/tiao_ji/baolubi/201509/t20150901_1310539.shtml'
        socket.setdefaulttimeout(5000)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36"}
        string = requests.get(url_2014, headers=headers, timeout=5000).content.decode()
        element = etree.HTML(string)
        ones = element.xpath('//table//tr')
        i = 1
        res_year = 2014
        res_uni_name = '南开大学'
        res_recommend_num = -1
        dao = DAO_报录比()
        for one in ones:
            # print(i, one.xpath('./td[1]/text()'), one.xpath('./td[2]/text()'))
            if i > 3 and i < 229:
                res_college_name = str(one.xpath('./td[1]/text()')[0]).strip('★')
                res_maj_name = str(one.xpath('./td[2]/text()')[0]).strip('★')
                res_register_num = int(one.xpath('./td[3]/text()')[0])
                res_enroll_num = int(one.xpath('./td[4]/text()')[0])
                print(i, res_year, res_uni_name, res_college_name, res_maj_name, res_register_num, res_enroll_num, res_recommend_num)
                dao.add_报录比(res_year, res_register_num, res_enroll_num, res_recommend_num, res_uni_name, res_college_name, res_maj_name)
            i += 1
if __name__ == '__main__':
    starttime = datetime.datetime.now()
    test = test_报录比_南开大学()
    # test.南开2014()
    # test.南开2015()
    # test.南开2016()
    # test.南开2017()
    test.南开2018()
    endtime = datetime.datetime.now()
    processtime = endtime - starttime
    print("开始时间: ", starttime, "   结束时间: ", endtime)
    print("运行时间: ", processtime, "秒")

