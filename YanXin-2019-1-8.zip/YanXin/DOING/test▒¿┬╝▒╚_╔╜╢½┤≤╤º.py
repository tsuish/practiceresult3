import requests
import socket
from lxml import etree
from YanXin.DOING.dao_报录比 import DAO_报录比
class test_报录比_山东大学:
    def 山东大学_2018(self):
        '''
            0:00:14.248004 秒
            1  : url_2017
            2  : res_year
            3  : requests.get(url_2017.......
            4  : if i > 3 and i < 209:
        '''
        url_2018 = 'http://kaoyan.eol.cn/tiao_ji/baolubi/201708/t20170817_1548144.shtml'
        socket.setdefaulttimeout(5000)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36"}
        string = requests.get(url_2018, headers=headers, timeout=5000).content.decode()
        element = etree.HTML(string)
        ones = element.xpath('//table//tr')
        i = 1
        res_year = 2018
        res_uni_name = '山东大学'
        res_recommend_num = -1
        dao = DAO_报录比()
        for one in ones:
            # print(i, one.xpath('./td[1]/text()'), one.xpath('./td[3]/text()'), one.xpath('./td[5]/text()'), one.xpath('./td[7]/text()'))
            if i > 1 and i < 420:
                # print(len(str(one.xpath('./td[1]/text()')[0]).split('（')))
                if len(str(one.xpath('./td[1]/text()')[0]).split('（')) > 1:
                    res_college_name = str(one.xpath('./td[1]/text()')[0]).split('（')[0]+'(威海)'
                else:
                    res_college_name = str(one.xpath('./td[1]/text()')[0])
                res_maj_name = str(one.xpath('./td[3]/text()')[0])
                res_register_num = int(one.xpath('./td[5]/text()')[0])
                res_enroll_num = int(one.xpath('./td[7]/text()')[0])
                if res_register_num == 0 and res_enroll_num == 0 :
                    print(i, res_maj_name, '没有报录比数据')
                else:
                    print(i, res_year, res_uni_name, res_college_name, res_maj_name, res_register_num, res_enroll_num, res_recommend_num)
                    # dao.update_报录比_单行更新(res_year, res_register_num, res_enroll_num, res_recommend_num, res_uni_name, res_college_name, res_maj_name)
            i += 1
    def 山东大学(self, url, res_year, startnum, endnum):
        '''
            0:00:14.248004 秒
            1  : url_2017
            2  : res_year
            3  : requests.get(url_2017.......
            4  : if i > 3 and i < 209:
        '''
        socket.setdefaulttimeout(5000)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36"}
        string = requests.get(url, headers=headers, timeout=5000).content.decode()
        element = etree.HTML(string)
        ones = element.xpath('//table//tr')
        i = 1
        res_uni_name = '山东大学'
        res_recommend_num = -1
        dao = DAO_报录比()
        for one in ones:
            # print(i, one.xpath('./td[1]/text()'), one.xpath('./td[3]/text()'), one.xpath('./td[5]/text()'), one.xpath('./td[7]/text()'))
            if i > startnum and i < endnum:
                if len(str(one.xpath('./td[1]/text()')[0]).split('（')) > 1:
                    res_college_name = str(one.xpath('./td[1]/text()')[0]).split('（')[0]+'(威海)'
                else:
                    res_college_name = str(one.xpath('./td[1]/text()')[0])
                res_maj_name = str(one.xpath('./td[3]/text()')[0])
                res_register_num = int(one.xpath('./td[5]/text()')[0])
                res_enroll_num = int(one.xpath('./td[7]/text()')[0])
                if res_register_num == 0 and res_enroll_num == 0 :
                    print(i, res_maj_name, '没有报录比数据')
                else:
                    print(i, res_year, res_uni_name, res_college_name, res_maj_name, res_register_num, res_enroll_num, res_recommend_num)
                    dao.add_报录比(res_year, res_register_num, res_enroll_num, res_recommend_num, res_uni_name, res_college_name, res_maj_name)
            i += 1
