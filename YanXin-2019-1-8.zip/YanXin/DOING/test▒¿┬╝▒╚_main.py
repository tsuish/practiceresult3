import datetime
from YanXin.DOING.test报录比_山东大学 import test_报录比_山东大学
from YanXin.DOING.test报录比_浙江大学 import test_报录比_浙江大学
from YanXin.DOING.test报录比_中山大学 import test_报录比_中山大学
from YanXin.DOING.test报录比_电子科技大学 import test_报录比_电子科技大学
from YanXin.DOING.test报录比_北京林业大学 import test_报录比_北京林业大学
from YanXin.DOING.test报录比_只无推免 import test_报录比_只无推免
from YanXin.DOING.test报录比_天津师范大学 import test_报录比_天津师范大学
from YanXin.DOING.test报录比_上海大学 import test_报录比_上海大学
if __name__ == '__main__':
    starttime = datetime.datetime.now()
    # test = test_报录比_山东大学()
    # test.山东大学_2018()
    # test.山东大学('http://kaoyan.eol.cn/tiao_ji/baolubi/201708/t20170817_1548144.shtml', '2017', 1, 420)
    # test.山东大学('http://kaoyan.eol.cn/ge_di_kao_yan/shandong/shan_dong/201608/t20160804_1437228.shtml', '2016', 3, 396)
    # test.山东大学('http://kaoyan.eol.cn/ge_di_kao_yan/shandong/shan_dong/201608/t20160804_1437222.shtml', '2015', 3, 406)
    # test.山东大学('http://kaoyan.eol.cn/ge_di_kao_yan/shandong/shan_dong/201608/t20160804_1437219.shtml', '2014', 3, 410)
    # test = test_报录比_浙江大学()
    # test.浙江大学('http://kaoyan.eol.cn/tiao_ji/baolubi/201712/t20171224_1575860.shtml', '2017', '浙江大学', 2, 292)
    # test.浙江大学('http://kaoyan.eol.cn/tiao_ji/baolubi/201708/t20170817_1548153.shtml', '2016', '浙江大学', 2, 296)
    # test.浙江大学('http://kaoyan.eol.cn/tiao_ji/baolubi/201601/t20160104_1354103.shtml', '2015', '浙江大学', 4, 291)
    # test.浙江大学('http://kaoyan.eol.cn/tiao_ji/baolubi/201601/t20160104_1354099.shtml', '2014', '浙江大学', 4, 277)
    # test = test_报录比_中山大学()
    # test.中山大学('http://kaoyan.eol.cn/tiao_ji/baolubi/201708/t20170808_1546311.shtml', '2017', '中山大学', 2, 575)
    # test = test_报录比_电子科技大学()
    # test.电子科技大学('http://kaoyan.eol.cn/ge_di_kao_yan/sichuan/si_chuan/201608/t20160812_1439365.shtml', '2014', '电子科技大学', 4, 98)
    # test = test_报录比_北京林业大学()
    # test.北京林业大学('http://kaoyan.eol.cn/ge_di_kao_yan/beijing/bei_jing/201608/t20160809_1438314.shtml', '2014', '北京林业大学', 4, 86)
    # test = test_报录比_只无推免()
    # test.大学('http://kaoyan.eol.cn/tiao_ji/baolubi/201601/t20160105_1354325.shtml', '2014', '中央财经大学', 4, 91, 1, 3, 4, 7)
    # test.大学('http://kaoyan.eol.cn/ge_di_kao_yan/beijing/bei_jing/201608/t20160812_1439366.shtml', '2014', '中央民族大学', 4, 113, 2, 4, 5, 6)
    # test.大学('http://kaoyan.eol.cn/ge_di_kao_yan/beijing/bei_jing/201608/t20160812_1439369.shtml', '2015', '中央民族大学', 4, 40, 2, '4', 5, 6)#出现问题：专业数据在td下的b标签内
    # test.大学('http://kaoyan.eol.cn/ge_di_kao_yan/beijing/bei_jing/201608/t20160812_1439369_1.shtml', '2015', '中央民族大学', 2, 64, 2, 4, 5, 6)#出现问题：专业数据在td下的b标签内
    # test.对外经贸大学("http://kaoyan.eol.cn/tiao_ji/baolubi/201707/t20170727_1543911.shtml", "2017", "对外经贸大学", 4, 67, 1, 2, 3, 4)
    # test.对外经贸大学("http://kaoyan.eol.cn/tiao_ji/baolubi/201707/t20170727_1543908.shtml", "2016", "对外经贸大学", 4, 67, 1, 2, 3, 4)
    # test.对外经贸大学("http://kaoyan.eol.cn/ge_di_kao_yan/beijing/bei_jing/201608/t20160808_1438038.shtml", "2015", "对外经贸大学", 4, 63, 1, 2, 3, 4)
    # test.对外经贸大学("http://kaoyan.eol.cn/tiao_ji/baolubi/201601/t20160116_1357978.shtml", "2014", "对外经贸大学", 4, 57, 1, 2, 3, 4)
    # test = test_报录比_天津师范大学()
    # test.天津师范大学("http://kaoyan.eol.cn/ge_di_kao_yan/tianjin/tian_jin/201608/t20160803_1436797.shtml", "2016", "天津师范大学", 4, 144, 2, 4, 5, 6, 7)
    # test.天津师范大学("http://kaoyan.eol.cn/ge_di_kao_yan/tianjin/tian_jin/201608/t20160803_1436793.shtml", "2015", "天津师范大学", 4, 144, 2, 4, 5, 6, 7)
    # test.天津师范大学("http://kaoyan.eol.cn/ge_di_kao_yan/tianjin/tian_jin/201608/t20160803_1436800.shtml", "2014", "天津师范大学", 4, 144, 1, 3, 0, 4, 5)
    test = test_报录比_上海大学()
    test.上海大学("http://kaoyan.eol.cn/tiao_ji/baolubi/201712/t20171224_1575879.shtml", "2017", "上海大学", 2, 116, 0, 1, 2, 3, -1)
    endtime = datetime.datetime.now()
    processtime = endtime - starttime
    print("开始时间: ", starttime, "   结束时间: ", endtime)
    print("运行时间: ", processtime, "秒")
