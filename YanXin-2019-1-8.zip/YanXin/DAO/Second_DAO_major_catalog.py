import pymysql


class Second_DAO_major_catalog:
    def __init__(self):
        pass



    # 更新专业目标表的 专业评估 和 所属学科 属性（这个模块创建于2018-11-9）
    def update_maj_level_maj_subject(self, maj_level, maj_subject, maj_uni_name, maj_name):
        # 打开数据库连接
        db = self.get_conn()
        # 使用cursor()方法获取操作游标
        cursor = db.cursor()
        # SQL 更新语句
        sql = "UPDATE major_catalog SET maj_level = '%s', maj_subject = '%s'  WHERE maj_uni_name = '%s' and maj_name = '%s'" % (maj_level, maj_subject, maj_uni_name, maj_name)
        try:
            # 执行sql语句
            cursor.execute(sql)
            # 执行sql语句
            db.commit()
            print("\t\t\t", maj_uni_name, maj_name, maj_level, "  update ok+++++++++++++++++++++++++++++++++++++++")
        except:
            # 发生错误时回滚
            print("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM")
            db.rollback()
        # 关闭数据库连接
        db.close()

    # 根据 maj_uni_name, maj_name 判断 maj_level 的 值是否为空，为空返回True, 非空返回False
    def maj_level_empty(self, maj_uni_name, maj_name):
        # 打开数据库连接
        db = self.get_conn()
        # 使用cursor()方法获取操作游标
        cursor = db.cursor()
        # SQL 更新语句，学术类型为空的数量
        sql = "select maj_level from major_catalog WHERE maj_uni_name = '%s' and maj_name = '%s' and maj_level = ''" % (maj_uni_name, maj_name)
        # 执行sql语句
        rows = cursor.execute(sql)
        # 执行sql语句
        if rows > 0:
            return True
        else:
            return False

    # 与数据库建立连接
    def get_conn(self):

        # 里皮的阿里云服务器
        # conn = pymysql.connect(host='39.105.39.215', port=3307, user="root", passwd="qq1040256886", db="yanxin", charset="utf8")

        # 本机的数据库
        conn = pymysql.connect(host='127.0.0.1', port=3306, user="root", passwd="root", db="yanxin", charset="utf8")
        return conn
